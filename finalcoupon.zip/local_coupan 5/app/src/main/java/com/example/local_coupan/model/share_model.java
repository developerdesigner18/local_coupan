package com.example.local_coupan.model;

public class share_model {
    public String share_name;
    public String first_name;

    public share_model(String share_name, String first_name) {
        this.share_name = share_name;
        this.first_name = first_name;
    }

    public String getShare_name() {
        return share_name;
    }

    public void setShare_name(String share_name) {
        this.share_name = share_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }
}


//    public String share_name;
//    public char first_name;
//
//    public share_model(String share_name, char first_name) {
//        this.share_name = share_name;
//        this.first_name = first_name;
//    }

