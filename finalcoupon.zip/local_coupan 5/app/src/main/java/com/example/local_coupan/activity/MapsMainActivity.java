package com.example.local_coupan.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.databinding.ActivityMapsMainBinding;
import com.example.local_coupan.preferences2;

public class MapsMainActivity extends AppCompatActivity {

    ActivityMapsMainBinding binding;
    private static final int REQUEST_PERMISSION_CODE = 101;
    preferences2 preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        if (ContextCompat.checkSelfPermission(MapsMainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MapsMainActivity.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(MapsMainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                ActivityCompat.requestPermissions(MapsMainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (ActivityCompat.checkSelfPermission(MapsMainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MapsMainActivity.this, new String[]{Manifest.permission.CAMERA}, REQUEST_PERMISSION_CODE);
            }
        }

        binding.cardLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferences.save(MapsMainActivity.this, preferences.KEY_ID, String.valueOf(""));
                Intent get_login = new Intent(MapsMainActivity.this, login_screen.class);
                get_login.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_login);
            }
        });

//        binding.imgLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent get_login = new Intent(MapsMainActivity.this, login_screen.class);
//                get_login.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(get_login);
//            }
//        });

        binding.lloutShowcoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_coupon = new Intent(MapsMainActivity.this, MainActivity.class);
                get_coupon.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_coupon);
            }
        });

        binding.lloutScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_scan = new Intent(MapsMainActivity.this, Scanner_activity.class);
                get_scan.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_scan);
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(MapsMainActivity.this,
                            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this).setTitle("Really Exit?").setMessage("Are you sure you want to exit?").setNegativeButton(android.R.string.no, null).setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);
//                MapsMainActivity.super.onBackPressed();
            }
        }).create().show();
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        switch (requestCode) {
//            case REQUEST_PERMISSION_CODE: {
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(this, "Permission Denied..", Toast.LENGTH_SHORT).show();
//                }
//            }
//        }
//    }
}