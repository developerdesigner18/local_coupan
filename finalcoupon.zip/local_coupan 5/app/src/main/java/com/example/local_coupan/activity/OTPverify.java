
package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.databinding.ActivityOtpverifyBinding;
import com.example.local_coupan.model.qrcode_scan.ScanQr;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class OTPverify extends AppCompatActivity implements Callback<ScanQr> {
    ActivityOtpverifyBinding binding;

    private long timeleftinmillisecond = 60000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOtpverifyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);


        binding.imgBudgetBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        int OTP = sh.getInt("OTP", 0);
        int otp_verify_done = OTP;

        new CountDownTimer(30000, 1000) {

            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {

                NumberFormat f = new DecimalFormat("00");

                long min = (millisUntilFinished / 60000) % 60;
                long sec = (millisUntilFinished / 1000) % 60;

                binding.txtresendOtp.setText(f.format(min) + ":" + f.format(sec));
                binding.txtcallerTime.setText(f.format(min) + ":" + f.format(sec));

            }

            @SuppressLint("SetTextI18n")
            public void onFinish() {

                binding.txtresendOtp.setText("00:00");
                binding.txtcallerTime.setText("00:00");

                Toast.makeText(OTPverify.this, "" + otp_verify_done, Toast.LENGTH_SHORT).show();

            }

        }.start();

        String ids = sh.getString("ids", "");

        Log.d("get_id_from_scanner", "onCreate: " + ids);
        Log.d("get_otp", "onCreate: " + OTP);

        binding.otp.setText(String.valueOf(OTP));

        binding.otp1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (binding.otp1.getText().toString().length() == 1) {
                    binding.otp2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        binding.otp2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (binding.otp2.getText().toString().length() == 1) {
                    binding.otp3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        binding.otp3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (binding.otp3.getText().toString().length() == 1) {
                    binding.otp4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        binding.otp4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!binding.otp1.getText().toString().isEmpty() &&
                        !binding.otp2.getText().toString().isEmpty() &&
                        !binding.otp3.getText().toString().isEmpty() &&
                        !binding.otp4.getText().toString().isEmpty()) {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            String user_otp1 = binding.otp1.getText().toString();
                            String user_otp2 = binding.otp2.getText().toString();
                            String user_otp3 = binding.otp3.getText().toString();
                            String user_otp4 = binding.otp4.getText().toString();

                            String otp_verify = user_otp1 + user_otp2 + user_otp3 + user_otp4;

                            int final_otp = Integer.parseInt(otp_verify);
                            Log.d("otp_done", "run: " + final_otp);

                            get_qrcode_verify(ids, final_otp);

                        }
                    }, 0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    public void get_qrcode_verify(String id, int OTPQRcode) {

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/coupon/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("id", id);
            paramObject.put("OTPQRCode", OTPQRcode);

            Log.d("devi123", "onCreate: " + paramObject);

            Call<ScanQr> userCall = apiInterface.get_scan(String.valueOf(paramObject));
            userCall.enqueue((Callback<ScanQr>) this);

        } catch (

                JSONException e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onResponse(Call<ScanQr> call, Response<ScanQr> response) {

        Log.d("viru_qrcode", "onResponse: " + response.raw());

        if (response.code() == 200) {

            Log.d("OTP_Code", "onResponse: " + response.body().getSuccess());

            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();
            String coupon_title = response.body().getData().getCouponTitle();
            if (response.body().getData().getPercentageDiscount() == null) {
                int percentageDiscount = 12;
                myEdit.putInt("percentageDiscount", percentageDiscount);
                myEdit.apply();
            } else {
                int percentageDiscount = response.body().getData().getPercentageDiscount();
                myEdit.apply();
            }
            String message = response.body().getMessage();

            myEdit.putString("coupon_title", coupon_title);
            myEdit.putString("message", message);
            myEdit.apply();


            Intent get_OTP = new Intent(OTPverify.this, coupon_verify_activity.class);
            get_OTP.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(get_OTP);
        } else {

            Toast.makeText(this, "Please Enter Correct OTP", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onFailure(Call<ScanQr> call, Throwable t) {
        Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
    }
}
