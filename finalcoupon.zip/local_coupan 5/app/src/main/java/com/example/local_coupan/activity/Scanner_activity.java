

package com.example.local_coupan.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.DecodeCallback;
import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.databinding.ActivityScannerBinding;
import com.example.local_coupan.model.GetQrcode;
import com.example.local_coupan.model.Get_id_vise_data.ID_CouponData;
import com.google.zxing.Result;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;


import java.net.MalformedURLException;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class Scanner_activity extends AppCompatActivity implements Callback<GetQrcode> {

    ActivityScannerBinding binding;
    private CodeScanner mCodeScanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityScannerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.backScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mCodeScanner = new CodeScanner(this, binding.scannerView);
        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(Scanner_activity.this, result.getText(), Toast.LENGTH_SHORT).show();
                        Log.d("qrcodescanner", "run: " + result.getText());

                        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
                        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
                        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
                        clientBuilder.addInterceptor(loggingInterceptor);

                        Retrofit retrofit = new Retrofit.Builder()
                                .baseUrl("http://54.90.77.44:8000/coupon/")
                                .addConverterFactory(ScalarsConverterFactory.create())
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();

                        ApiInterface apiInterface = retrofit.create(ApiInterface.class);

                        try {

                            String id = result.getText();
                            String result123 = id.substring(1, id.length() - 1);

                            JSONObject paramObject = new JSONObject();
                            paramObject.put("id", result123);
                            Log.d("devi123", "onCreate: " + paramObject);
                            Call<ID_CouponData> userCall = apiInterface.getCoupon_data(String.valueOf(paramObject));
                            userCall.enqueue(new Callback<ID_CouponData>() {
                                @Override
                                public void onResponse(Call<ID_CouponData> call, Response<ID_CouponData> response) {
                                    Log.d("viru_qrcode", "onResponse: " + response.raw());
//                                    Toast.makeText(Scanner_activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();

                                    if (response.code() == 200) {

//                                        Toast.makeText(Scanner_activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();

                                        assert response.body() != null;
                                        String title = response.body().getCouponData().getCouponTitle();
                                        String user_id = response.body().getCouponData().getUserId();
                                        String coupon_id = response.body().getCouponData().getId();
//                                        String title = response.body().getCouponData().getCouponTitle();
//                                        String title = response.body().getCouponData().getCouponTitle();
//                                        String title = response.body().getCouponData().getCouponTitle();
                                        String Copon_image = (String) response.body().getCouponData().getCouponImage();

                                        binding.userid.setText(user_id);
                                        binding.offerid.setText(coupon_id);
                                        binding.discount.setText(title);
//                                        String user_id = response.body().getCouponData().getUserId();

                                        URL url = null;
                                        try {
                                            url = new URL(Copon_image);
                                        } catch (MalformedURLException e) {
                                            e.printStackTrace();
                                        }
                                        Picasso.get().load(String.valueOf(url)).into(binding.couponImage);

                                        binding.titleCouponName.setText(title);

                                        binding.titleCouponName.setVisibility(View.VISIBLE);
                                        binding.offerid.setVisibility(View.VISIBLE);
                                        binding.textUserId.setVisibility(View.VISIBLE);
                                        binding.materialCardView.setVisibility(View.VISIBLE);
                                        binding.textDescription.setVisibility(View.VISIBLE);
                                        binding.textOfferId.setVisibility(View.VISIBLE);
                                        binding.userid.setVisibility(View.VISIBLE);
                                        binding.discount.setVisibility(View.VISIBLE);
                                        binding.btnRedeem.setVisibility(View.VISIBLE);

                                        binding.btnRedeem.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                qrcode(result.getText());
                                            }
                                        });
                                    } else {
                                        Toast.makeText(Scanner_activity.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
                                    }
                                }
                                @Override
                                public void onFailure(Call<ID_CouponData> call, Throwable t) {
                                    Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
                                    Toast.makeText(Scanner_activity.this, ""+t, Toast.LENGTH_SHORT).show();
                                }
                            });
                        } catch (
                                JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        binding.scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

    @Override
    protected void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }

    public void qrcode(String qrcode_id) {

        String final_id = qrcode_id;
        String result = final_id.substring(1, final_id.length() - 1);

        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();

        myEdit.putString("ids", result);
        myEdit.apply();


        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/coupon/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("id", result);
            Log.d("devi123", "onCreate: " + paramObject);
            Call<GetQrcode> userCall = apiInterface.get_qrcode_id(String.valueOf(paramObject));
            userCall.enqueue((Callback<GetQrcode>) this);

        } catch (

                JSONException e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onResponse(Call<GetQrcode> call, Response<GetQrcode> response) {

        Log.d("viru_qrcode", "onResponse: " + response.raw());

        if (response.code() == 200) {

//            Toast.makeText(this, "" + response.raw(), Toast.LENGTH_LONG).show();

            Log.d("OTP_Code", "onResponse: " + response.body().getSuccess());


            int otp = response.body().getOTPCode();
            Log.d("OTP_Code", "onResponse: " + otp);
            assert response.body() != null;
            Log.d("OTP_Code", "onResponse: " + response.body().getMessage());
            Toast.makeText(this, "" + otp, Toast.LENGTH_SHORT).show();

            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();

            myEdit.putInt("OTP", otp);
            myEdit.apply();

            Intent get_OTP = new Intent(Scanner_activity.this, OTPverify.class);
            get_OTP.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(get_OTP);
        } else {

            Toast.makeText(this, "Enter Correct OTP", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public void onFailure(Call<GetQrcode> call, Throwable t) {
        Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
    }
}