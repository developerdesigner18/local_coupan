package com.example.local_coupan.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.local_coupan.databinding.ActivityTermsBinding;
import com.example.local_coupan.preferences2;

public class Terms_activity extends AppCompatActivity {

    ActivityTermsBinding binding;
    preferences2 preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTermsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Bundle extras = getIntent().getExtras();
        binding.imgTermsBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        if (extras.getString("type").equals("1")) {

            binding.lloutTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_couponterms = new Intent(Terms_activity.this, Coupon_terms_activity.class);
                    get_couponterms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_couponterms.putExtra("type", "1");
                    startActivity(get_couponterms);
                }
            });

            binding.lloutYucallterms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_yucall_terms = new Intent(Terms_activity.this, Yucall_coupon_activity.class);
                    get_yucall_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_yucall_terms.putExtra("type", "1");
                    startActivity(get_yucall_terms);

                }
            });

        } else if (extras.getString("type").equals("2")) {

            binding.imgTermsBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_add = new Intent(Terms_activity.this, Addcoupon_activity.class);
                    get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_add.putExtra("type", "2");
                    get_add.putExtra("type2", "30");
                    preferences.save(Terms_activity.this, preferences.KEY_Type5, String.valueOf(2));
                    startActivity(get_add);
                }
            });
            binding.lloutTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_couponterms = new Intent(Terms_activity.this, Coupon_terms_activity.class);
                    get_couponterms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_couponterms.putExtra("type", "2");
                    startActivity(get_couponterms);

                }
            });
            binding.lloutYucallterms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_yucall_terms = new Intent(Terms_activity.this, Yucall_coupon_activity.class);
                    get_yucall_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_yucall_terms.putExtra("type", "2");
                    startActivity(get_yucall_terms);
                }
            });
        }
    }
}