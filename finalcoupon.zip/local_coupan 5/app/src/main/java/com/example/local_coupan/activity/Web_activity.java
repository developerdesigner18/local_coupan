
package com.example.local_coupan.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.RetrofitClient;
import com.example.local_coupan.databinding.ActivityWebBinding;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Web_activity extends AppCompatActivity {

    ActivityWebBinding binding;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWebBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding = ActivityWebBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String url1 = getIntent().getStringExtra("payment_url");
        Log.d("viru_name1", "onCreate: " + url1);
        String url = url1;

        binding.webview.loadUrl(url);
        binding.webview.getSettings().setJavaScriptEnabled(true);
        binding.webview.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {

//                Toast.makeText(Web_activity.this, view.getTitle(), Toast.LENGTH_SHORT).show();
                Log.d("devi3 1 ", view.getUrl());
                Log.d("devi3 2 ", view.getTitle());
                Log.d("devi3 3 ", view.getOriginalUrl());
                String uuu = "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=EC-56 350085912097506";
                if (view.getTitle().equals("Payment")) {
                    Intent intent = new Intent(Web_activity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    intent.putExtra("type", "1");

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(intent);
                        }
                    }, 2000);
                }
            }
        });
    }
}