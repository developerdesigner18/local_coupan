package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.R;
import com.example.local_coupan.adapter.share_recycle_adapter;
import com.example.local_coupan.databinding.ActivityDirectShareBinding;
import com.example.local_coupan.model.share_data.ShareData;
import com.example.local_coupan.model.userlist_model.Userlist;
import com.example.local_coupan.preferences2;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class Direct_share_Activity extends AppCompatActivity {

    preferences2 preferences;
    ActivityDirectShareBinding binding;
    share_recycle_adapter share_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDirectShareBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        String user_id = sh.getString("user_id", "");
//        Toast.makeText(this, "" + userid, Toast.LENGTH_SHORT).show();
        get_userlist(user_id);
//        get_userlist("63bfb35c970102da6bd299ce");

        binding.imgDirectShareBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent get_share = new Intent(Direct_share_Activity.this, Share_activity.class);
                get_share.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_share);
                finish();

            }
        });
        binding.searchviewShare.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                share_adapter.getFilter().filter(newText);
                return false;
            }
        });

        RecyclerView.LayoutManager manager = new LinearLayoutManager(this);
        binding.recyclerDirectShare.setLayoutManager(manager);
        binding.recyclerDirectShare.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
//        binding.recyclerDirectShare.setLayoutManager(new LinearLayoutManager(Direct_share_Activity.this, 1));

        LinearLayoutManager layoutManager = new LinearLayoutManager(Direct_share_Activity.this, LinearLayoutManager.VERTICAL, false);
        binding.recyclerDirectShare.setLayoutManager(layoutManager);

    }

    public void get_userlist(String userid) {

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/user/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("id", userid);

            Log.d("devi123", "onCreate: " + paramObject);
            Call<Userlist> userCall = apiInterface.get_user_list(String.valueOf(paramObject));
            userCall.enqueue(new Callback<Userlist>() {
                @Override
                public void onResponse(Call<Userlist> call, Response<Userlist> response) {

                    binding.prgressShare.setVisibility(View.INVISIBLE);

//                Toast.makeText(Direct_share_Activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();
                    Log.d("share_api", "onResponse: " + response.raw());

                    share_adapter = new share_recycle_adapter(Direct_share_Activity.this, response.body().getLoginData());
                    binding.recyclerDirectShare.setAdapter(share_adapter);

                    share_adapter.setOnItemClicklistner(new share_recycle_adapter.OnItemClickListener() {
                        @Override
                        public void oncheck_click(int position) {

                            Log.d("checkposition123", "on_next_click: " + position);
//                            binding.

                        }

                        @Override
                        public void on_next_click(int position) {

                            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);

                            String coupon_id = pref.getString("id1", "");
                            String ids = preferences.get(Direct_share_Activity.this, preferences.KEY_ID);
                            String shareuserid = response.body().getLoginData().get(position).getId();
                            Log.d("position123", "on_next_click: " + position);
                            get_share_data(ids, shareuserid, coupon_id, coupon_id);

                        }
                    });
                }

                @Override
                public void onFailure(Call<Userlist> call, Throwable t) {
                    Toast.makeText(Direct_share_Activity.this, "" + t, Toast.LENGTH_SHORT).show();
                }
            });
        } catch (
                JSONException e) {
            e.printStackTrace();
        }
    }

    public void get_share_data(String userID, String shareUserId, String couponID, String parent_id) {

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/coupon/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);

        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("userID", userID);
            paramObject.put("shareUserId", shareUserId);
            paramObject.put("couponID", couponID);
            paramObject.put("parent_id", parent_id);

            Log.d("devi123", "onCreate: " + paramObject);

            Call<ShareData> userCall = apiInterface.get_share_data(String.valueOf(paramObject));
            userCall.enqueue(new Callback<ShareData>() {
                @Override
                public void onResponse(Call<ShareData> call, Response<ShareData> response) {
                    Log.d("viru_qrcode", "onResponse: " + response.raw());

                    if (response.code() == 200) {

                        String message = response.body().getMessage();

                        Log.d("message123", "onResponse: " + message);
                        Log.d("OTP_Code", "onResponse: " + response.body().getSuccess());

                        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                        SharedPreferences.Editor myEdit = pref.edit();
                        myEdit.apply();

                        if (message.equalsIgnoreCase("Successfully Created shared coupon")) {

                            Toast.makeText(Direct_share_Activity.this, "" + message, Toast.LENGTH_LONG).show();
                            Intent get_OTP = new Intent(Direct_share_Activity.this, coupon_share.class);
                            get_OTP.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(get_OTP);

                        } else {
                            alert_message(message);
                        }
                    } else {
                        Toast.makeText(Direct_share_Activity.this, "Please Enter Correct OTP", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ShareData> call, Throwable t) {
                    Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void alert_message(String message_from_share) {
        new AlertDialog.Builder(this)
                .setTitle("Share Message")
                .setMessage(message_from_share)
                .setNeutralButton(R.string.Yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        binding.prgressShare.setVisibility(View.VISIBLE);
                        binding.recyclerDirectShare.setVisibility(View.GONE);
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                binding.prgressShare.setVisibility(View.GONE);
                                Intent get_main = new Intent(Direct_share_Activity.this, MainActivity.class);
                                get_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(get_main);
                            }
                        },2000);
                    }
                }).create().show();
    }
}