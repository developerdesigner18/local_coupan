package com.example.local_coupan.activity;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.R;

import com.example.local_coupan.databinding.ActivitySelectMapsBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.GeoPoint;

import java.io.IOException;
import java.util.List;

public class select_maps_Activity extends FragmentActivity implements OnMapReadyCallback {

    ActivitySelectMapsBinding binding;
    String maping = "no";

    Location currentlocation;
    FusedLocationProviderClient fusedLocationProviderClient;

    String Array;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();
//        String locc="401, Marvella Business Hub, opp. Pal RTO Adajan, Pal Gam, Surat, Gujarat 395009";
//        getLocationFromAddress(locc);
//        if (getIntent().getStringExtra("type").equals("1")) {

        maping = "one";

//        Bundle b = getIntent().getExtras();
//        Array = b.getString("Array");
//        Log.d("aray_loation", "onCreate: " + Array);


        binding.imgMapsBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
//        } else if (getIntent().getStringExtra("type").equals("2")) {

//            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                    .findFragmentById(R.id.select_map);
//            assert mapFragment != null;
//            mapFragment.getMapAsync(this);
//
//            maping = "two";
//            binding.imgMapsBack.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Intent get_location = new Intent(select_maps_Activity.this, location_activity.class);
//                    get_location.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    get_location.putExtra("type", "2");
//                    startActivity(get_location);
//                    finish();
//                }
//            });
//        }
//    }

    }

    private void fetchLastLocation() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentlocation = location;

                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.select_map);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(select_maps_Activity.this);

                }
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String loccaa = sh.getString("new_location", "");
        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();

        if (loccaa.equals("first")) {

            if (getIntent().getStringExtra("map_pin").equals("current")) {

                LatLng current_latlang = new LatLng(currentlocation.getLatitude(), currentlocation.getLongitude());
                MarkerOptions markerOptions = new MarkerOptions().position(current_latlang).title("I am Here");

                String latitude = String.valueOf(currentlocation.getLatitude());

                String longitude = String.valueOf(currentlocation.getLongitude());
                Log.d("latlang", "onMapReady: " + currentlocation.getLatitude() + currentlocation.getLongitude());

                myEdit.putString("latitude", latitude);
                myEdit.putString("longitude", longitude);

                myEdit.apply();
                googleMap.animateCamera(CameraUpdateFactory.newLatLng(current_latlang));
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(current_latlang, 14));
                googleMap.addMarker(markerOptions);

            } else if (getIntent().getStringExtra("map_pin").equals("address")) {

                String latitude = sh.getString("latitude123", "");
                String longitude = sh.getString("longitude123", "");

                double l1 = Double.parseDouble(latitude);
                double l2 = Double.parseDouble(longitude);

                LatLng select_latlang = new LatLng(l1, l2);

                myEdit.putString("latitude", latitude);
                myEdit.putString("longitude", longitude);

                myEdit.apply();

                MarkerOptions markerOptions2 = new MarkerOptions().position(select_latlang).title("I am Here");
                googleMap.animateCamera(CameraUpdateFactory.newLatLng(select_latlang));
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(select_latlang, 14));
                googleMap.addMarker(markerOptions2);
            }

        } else {

            Double pinnn1 = Double.valueOf(sh.getString("latitude", ""));
            Double pinnn2 = Double.valueOf(sh.getString("longitude", ""));

            Log.d("latlang", "onMapReady: " + pinnn1 + pinnn2);
//            LatLng latLng = new LatLng(pinnn1, pinnn2);
            LatLng current_latlang = new LatLng(currentlocation.getLatitude(), currentlocation.getLongitude());

            MarkerOptions markerOptions = new MarkerOptions().position(current_latlang).title("I am Here");
            googleMap.animateCamera(CameraUpdateFactory.newLatLng(current_latlang));
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(current_latlang, 14));
            googleMap.addMarker(markerOptions);

        }

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            public void onMapClick(@NonNull LatLng point) {

                myEdit.putString("new_location", "second");
                myEdit.apply();

                googleMap.clear();

//                Toast.makeText(select_maps_Activity.this, point.latitude + ", " + point.longitude, Toast.LENGTH_SHORT).show();
                Log.d("viru_map", "onMapClick: " + point.latitude + " " + point.longitude);

                String latitude = String.valueOf(point.latitude).substring(0, 6);
                String longitude = String.valueOf(point.longitude).substring(0, 6);

                double latval = Double.parseDouble(latitude);
                double longval = Double.parseDouble(longitude);

                LatLng sydney = new LatLng(latval, longval);

                Log.d("viru_map1", "onMapClick: " + sydney);
                googleMap.addMarker(new MarkerOptions().position(sydney));
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(sydney, 14));
                myEdit.putString("selected_pin", String.valueOf(sydney));
                myEdit.apply();
                Log.d("viru_map", "onMapClick: " + latitude + " " + longitude);

                myEdit.putString("latitude", latitude);
                myEdit.putString("longitude", longitude);
                myEdit.apply();

//                String address1 = getIntent().getStringExtra("address1");
//                String address2 = getIntent().getStringExtra("address2");
//                String town_city = getIntent().getStringExtra("town_city");
//                String postcode = getIntent().getStringExtra("postcode");
//                String opening_times = getIntent().getStringExtra("opening_times");
//
//                Log.d("dynamic_data", "onMapClick: " + address1 + address1 + town_city + postcode + opening_times);


//                get_location.putExtra("address1", address1);
//                get_location.putExtra("address2", address2);
//                get_location.putExtra("town_city", town_city);
//                get_location.putExtra("postcode", postcode);
//                get_location.putExtra("opening_times", opening_times);

//                get_location.putExtra("Array", String.valueOf(Array));

//                Log.d("aray_loation", "onMapClick: " + Array);
//                get_location.putExtra("navigate", "null");

//                myEdit.apply();
//                if (maping.equals("one")) {
//                    get_location.putExtra("type", "1");

//                } else if (maping.equals("two")) {
//                    Toast.makeText(select_maps_Activity.this, "2", Toast.LENGTH_SHORT).show();
//                    get_location.putExtra("type", "2");
//                    get_location.putExtra("type2", "123");
//                    Handler handler = new Handler();
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            startActivity(get_location);
//                            finish();
//                        }
//                    }, 3000);
//                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        Intent get_location = new Intent(select_maps_Activity.this, location_activity.class);
        get_location.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        String latitude = sh.getString("latitude", "");
        String longitude = sh.getString("longitude", "");


        String address1 = getIntent().getStringExtra("address1");
        String address2 = getIntent().getStringExtra("address2");
        String town_city = getIntent().getStringExtra("town_city");
        String postcode = getIntent().getStringExtra("postcode");
        String opening_times = getIntent().getStringExtra("opening_times");

        Log.d("dynamic_data", "onMapClick: " + address1 + address1 + town_city + postcode + opening_times);

        get_location.putExtra("address1", address1);
        get_location.putExtra("address2", address2);
        get_location.putExtra("town_city", town_city);
        get_location.putExtra("postcode", postcode);
        get_location.putExtra("opening_times", opening_times);
        get_location.putExtra("Array", String.valueOf(Array));
        Log.d("latlang", "onClick: " + latitude + " " + longitude);

        get_location.putExtra("navigate", "null");
        get_location.putExtra("type", "1");
        startActivity(get_location);
    }
}