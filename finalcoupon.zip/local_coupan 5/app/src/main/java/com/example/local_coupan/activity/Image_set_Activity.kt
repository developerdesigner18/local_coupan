package com.example.local_coupan.activity

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.local_coupan.R
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class Image_set_Activity : AppCompatActivity() {

    lateinit var img: ImageView
    lateinit var bt1: Button
    lateinit var bt2: Button
    lateinit var imageuri: Uri

    private val contract = registerForActivityResult(ActivityResultContracts.GetContent()) {
        imageuri = it!!
        img.setImageURI(it)
        Log.d("bitmapimage 4 ", " " + it)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_set)

        var pref = getSharedPreferences("MySharedPref", MODE_PRIVATE)
        var myEdit = pref.edit()
//        imageuri =  pref.getString("imageURL","")
//        setup()
//        getRealPathFromURI(j , applicationContext )
    }

    fun getRealPathFromURI(uri: Uri, context: Context): String? {
        val returnCursor = context.contentResolver.query(uri, null, null, null, null)
        val nameIndex = returnCursor!!.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        val sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE)
        returnCursor.moveToFirst()
        val name = returnCursor.getString(nameIndex)
        val size = returnCursor.getLong(sizeIndex).toString()
        val file = File(context.filesDir, name)
        try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val outputStream = FileOutputStream(file)
            var read = 0
            val maxBufferSize = 1 * 1024 * 1024
            val bytesAvailable: Int = inputStream?.available() ?: 0
            //int bufferSize = 1024;
            val bufferSize = Math.min(bytesAvailable, maxBufferSize)
            val buffers = ByteArray(bufferSize)
            while (inputStream?.read(buffers).also {
                    if (it != null) {
                        read = it
                    }
                } != -1) {
                outputStream.write(buffers, 0, read)
            }
            Log.e("File Size", "Size " + file.length())
            inputStream?.close()
            outputStream.close()
            Log.e("File Path", "Path " + file.path)

        } catch (e: java.lang.Exception) {
            Log.e("Exception", e.message!!)
        }
        return file.path
    }


    private fun setup() {
        img = findViewById(R.id.img);
        bt1 = findViewById(R.id.bt1);

        bt1.setOnClickListener { contract.launch("image/*") }
        bt2 = findViewById(R.id.bt2);

        bt2.setOnClickListener { upload() }
    }

    private fun upload() {

        val fileDir = applicationContext.filesDir
        val file = File(fileDir, "image.png")

        val inputStream = contentResolver.openInputStream(imageuri)
        val outputStream = FileOutputStream(file)
        inputStream!!.copyTo(outputStream)

        val requestBody = file.asRequestBody("image/*".toMediaTypeOrNull())

        val part = MultipartBody.Part.createFormData("couponImage", file.name, requestBody)
        Log.d("bitmapimage", "upload: " + file)
        Log.d("bitmapimage", "upload: " + part)
        val intent = Intent(this@Image_set_Activity, Addcoupon_activity::class.java)
        intent.putExtra("Username", imageuri)
        intent.putExtra("type", "1")
        intent.putExtra("type2", "10")
        startActivity(intent)

//        val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
//        var editor = sharedPreference.edit()
//        editor.putString("username", part)
//        editor.putLong("l",100L)
//        editor.commit()

    }

//    fun convertBitmapToFile(context: Context, bitmap: Bitmap): Uri {
//        val file = File(Environment.getExternalStorageDirectory().toString() + File.separator)
//        file.createNewFile()
//        // Convert bitmap to byte array
//        val baos = ByteArrayOutputStream()
//        bitmap.compress(Bitmap.CompressFormat.PNG, 0, baos) // It can be also saved it as JPEG
//        val bitmapdata = baos.toByteArray()
//    }
}