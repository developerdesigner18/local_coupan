package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.R;
import com.example.local_coupan.databinding.ActivityCouponDetailsBinding;
import com.example.local_coupan.model.preview.Preview;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class Coupon_details extends AppCompatActivity {
    ActivityCouponDetailsBinding binding;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCouponDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);


        if (getIntent().getStringExtra("type").equals("2")) {

            String coupon_id = sh.getString("coupon_id", "");
            preview_data(coupon_id);

            binding.imgDetailsBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            binding.mapOpen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_map = new Intent(Coupon_details.this, select_location.class);
                    get_map.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_map);
                }
            });
            binding.dealTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_offer_terms = new Intent(Coupon_details.this, Offer_terms_activity.class);
                    get_offer_terms.putExtra("type", "2");
//                    get_offer_terms.putExtra("image", image);
                    get_offer_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_offer_terms);
                }
            });
            binding.uploadImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_offer_terms = new Intent(Coupon_details.this, Share_activity.class);
                    get_offer_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_offer_terms);
                }
            });
            binding.yucallTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_yucall_terms = new Intent(Coupon_details.this, Yucall_terms_activity.class);
                    get_yucall_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_yucall_terms);
                }
            });

        } else {
            String id = sh.getString("id", "");
            preview_data(id);

            binding.imgDetailsBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            binding.mapOpen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_map = new Intent(Coupon_details.this, select_location.class);
                    get_map.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_map);
                }
            });
            binding.dealTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_offer_terms = new Intent(Coupon_details.this, Offer_terms_activity.class);
                    get_offer_terms.putExtra("type", "2");
//                    get_offer_terms.putExtra("image", image);
                    get_offer_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_offer_terms);
                }
            });
            binding.uploadImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_offer_terms = new Intent(Coupon_details.this, Share_activity.class);
                    get_offer_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_offer_terms);
                }
            });
            binding.yucallTerms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_yucall_terms = new Intent(Coupon_details.this, Yucall_terms_activity.class);
                    get_yucall_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_yucall_terms);
                }
            });
        }
    }

    public void preview_data(String id) {

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/coupon/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("id", id);
            Log.d("devi123", "onCreate: " + paramObject);
            Call<Preview> userCall = apiInterface.preview_data(String.valueOf(paramObject));
            userCall.enqueue(new Callback<Preview>() {
                @SuppressLint("ResourceAsColor")
                @Override
                public void onResponse(Call<Preview> call, Response<Preview> response) {
                    Log.d("viru_qrcode", "onResponse: " + response.raw());

                    binding.lloutDetails.setVisibility(View.VISIBLE);
                    binding.progressDetails.setVisibility(View.INVISIBLE);

//                    Toast.makeText(Coupon_details.this, "" + response.raw(), Toast.LENGTH_SHORT).show();
                    if (response.code() == 200) {

                        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                        SharedPreferences.Editor myEdit = pref.edit();

                        String QRCodeImage = response.body().getPreviewCouponData().getQRCodeImage();
                        String CouponImage = response.body().getPreviewCouponData().getCouponImage();
                        String title = response.body().getPreviewCouponData().getTitle();
                        String coupon_id = response.body().getPreviewCouponData().getCouponId();
                        String brand = response.body().getPreviewCouponData().getBrand();
                        String product = response.body().getPreviewCouponData().getProduct();
                        String deal = response.body().getPreviewCouponData().getDeal();
                        String valid = response.body().getPreviewCouponData().getStatus();
                        String expiry_date = response.body().getPreviewCouponData().getExpiryDate();
                        String ex_date = expiry_date.substring(0, 10);
                        String expiry_count = String.valueOf(response.body().getPreviewCouponData().getExpiryCountDown());
                        String description = response.body().getPreviewCouponData().getDescription();
                        String terms = response.body().getPreviewCouponData().getTerms();
                        String[] expiry_time = expiry_date.split("T");
                        String final_time = expiry_time[1];
                        String time = final_time.substring(0, 8);
                        Float discount = response.body().getPreviewCouponData().getDiscountPrice();
                        String dis_price = String.valueOf(discount);
                        Float regular = response.body().getPreviewCouponData().getNormalPrice();
                        String reg_price = String.valueOf(regular);

                        String address1 = response.body().getPreviewCouponData().getAddress().getAddress1();
                        String address2 = response.body().getPreviewCouponData().getAddress().getAddress2();
                        String city = response.body().getPreviewCouponData().getAddress().getCity();
                        String country = response.body().getPreviewCouponData().getAddress().getPostcode();
                        String latitude = response.body().getPreviewCouponData().getAddress().getLatitude();
                        String longitude = response.body().getPreviewCouponData().getAddress().getLongitude();
                        String address_image = response.body().getPreviewCouponData().getAddress().getAddressImage();

                        Log.d("lat_lang123", "onResponse: " + latitude + " " + longitude);
                        Log.d("devi6", "onResponse: " + latitude);

                        if (latitude == null) {
                            latitude = "54.51381236935253";
                            myEdit.putString("latitude", latitude);
                            myEdit.apply();
                        } else if (latitude.equalsIgnoreCase("latitude")) {
                            latitude = "54.51381236935253";
                            myEdit.putString("latitude", latitude);
                            myEdit.apply();
                        } else {
                            String lat = latitude.substring(0, 6);
                            myEdit.putString("latitude", lat);
                        }

                        if (longitude == null) {
                            longitude = "-2.0904716594366652";
                            myEdit.putString("longitude", longitude);
                            myEdit.apply();
                        } else if (longitude.equalsIgnoreCase("longitude")) {
                            longitude = "-2.0904716594366652";
                            myEdit.putString("longitude", longitude);
                            myEdit.apply();
                        } else {
                            String lang = longitude.substring(0, 6);
                            myEdit.putString("longitude", lang);
                            myEdit.apply();
                        }

                        String lauch_date = response.body().getPreviewCouponData().getLaunchDate();
                        String ln_date = lauch_date.substring(0, 10);

                        boolean share = response.body().getPreviewCouponData().getShared();
                        Log.d("shre123", "onResponse: " + share);

                        myEdit.putString("terms", terms);
                        myEdit.putString("CouponImage", CouponImage);
                        myEdit.putString("address1", address1);
                        myEdit.putString("address2", address2);
                        myEdit.putString("city", city);
                        myEdit.putString("country", country);
                        myEdit.putString("address_image", address_image);
                        myEdit.putString("title", title);
                        myEdit.putString("brand", brand);
                        myEdit.apply();

                        binding.txtTitlePrevir.setText(title);
                        binding.txtCouponId.setText(coupon_id);
                        binding.txtBrand.setText(brand);
                        binding.txtProduct.setText(product);
                        binding.txtDealtype.setText(deal);
                        binding.status.setText(valid);
                        binding.txtExpiryDate.setText(ex_date);
                        binding.txtExpiryCountdown.setText(expiry_count);
                        binding.txtDescription.setText(description);
                        binding.txtExpiryTime.setText(time);
                        binding.discountPrice.setText(dis_price);
                        binding.txtRegularPrice.setText(reg_price);
                        binding.launchDate.setText(ln_date);
                        binding.txtRegularPrice.setPaintFlags(binding.txtRegularPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

                        if (share) {
                            binding.uploadImage.setVisibility(View.VISIBLE);
                        } else {
                            binding.uploadImage.setVisibility(View.INVISIBLE);
                        }

                        if (valid.equals("INVALID")) {
                            binding.status.setTextColor(R.color.black);
                        } else if (valid.equals("VALID")) {
                            binding.status.setTextColor(R.color.green);
                        }

                        URL url = null;
                        try {
                            url = new URL(QRCodeImage);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                        Picasso.get().load(String.valueOf(url)).into(binding.qrCode2);

                        URL url1 = null;
                        try {
                            url1 = new URL(CouponImage);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        Picasso.get().load(String.valueOf(url1)).into(binding.couponImage);


                    } else {
                        Toast.makeText(Coupon_details.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Preview> call, Throwable t) {
                    Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
                }
            });

        } catch (
                JSONException e) {
            e.printStackTrace();
        }
    }
}