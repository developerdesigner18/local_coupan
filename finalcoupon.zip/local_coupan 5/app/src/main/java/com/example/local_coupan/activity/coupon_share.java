package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.databinding.ActivityCouponShareBinding;
import com.example.local_coupan.model.play_pause.PlayPauseStatus;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class coupon_share extends AppCompatActivity {
    ActivityCouponShareBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCouponShareBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);


        String scannedRedemptions = sh.getString("scannedRedemptions", "");
        int deliveries = sh.getInt("deliveries", 0);

        String del = String.valueOf(deliveries);

        binding.deliveries.setText(del);
        binding.scanned.setText(scannedRedemptions);

        Boolean status = sh.getBoolean("status", true);

        if (status.equals(true)) {
            binding.truePercentage1.setVisibility(View.VISIBLE);
        } else if (status.equals(false)) {
            binding.truePercentage2.setVisibility(View.VISIBLE);
        }

        String share_name = getIntent().getStringExtra("share_name");
        binding.userName.setText(share_name);


        binding.imgBackCouponList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                coupon_share.super.onBackPressed();

            }
        });

        binding.lloutLive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                binding.truePercentage1.setVisibility(View.VISIBLE);
                binding.truePercentage2.setVisibility(View.GONE);

                String id = sh.getString("id1", "");
                Log.d("coupon_id", "onCreate: " + id);
//                change_status(id);

            }
        });
        binding.lloutPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                binding.truePercentage2.setVisibility(View.VISIBLE);
                binding.truePercentage1.setVisibility(View.GONE);

                String id = sh.getString("id1", "");
                Log.d("coupon_id", "onCreate: " + id);
//                change_status(id);

            }
        });
    }

//    public void change_status(String id) {
//        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
//        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
//        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
//        clientBuilder.addInterceptor(loggingInterceptor);
//
//        Retrofit retrofit = new Retrofit.Builder()
//                .baseUrl("http://54.90.77.44:8000/coupon/")
//                .addConverterFactory(ScalarsConverterFactory.create())
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//
//        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
//        try {
//
//            JSONObject paramObject = new JSONObject();
//            paramObject.put("id", id);
//            Log.d("devi123", "onCreate: " + paramObject);
//            Call<PlayPauseStatus> userCall = apiInterface.get_play_pause_status(String.valueOf(paramObject));
//            userCall.enqueue(new Callback<PlayPauseStatus>() {
//                @Override
//                public void onResponse(Call<PlayPauseStatus> call, Response<PlayPauseStatus> response) {
//                    Log.d("viru_qrcode", "onResponse: " + response.raw());
//
//                    if (response.code() == 200) {
//
//                        Boolean get_play_pause = response.body().getData().getPlayPauseStatus();
//                        Log.d("OTP_Code", "onResponse: " + get_play_pause);
//
////                        Toast.makeText(coupon_share.this, "" + response.raw(), Toast.LENGTH_SHORT).show();
//
//                        Handler handler = new Handler();
//                        handler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                Intent i = new Intent(coupon_share.this, MainActivity.class);
//                                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                                startActivity(i);
//
//                            }
//                        }, 0);
//
//                    } else {
//                        Toast.makeText(coupon_share.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
//                    }
//
//                }
//
//                @Override
//                public void onFailure(Call<PlayPauseStatus> call, Throwable t) {
//                    Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
//
//                }
//            });
//
//        } catch (
//
//                JSONException e) {
//            e.printStackTrace();
//
//        }
//    }
}