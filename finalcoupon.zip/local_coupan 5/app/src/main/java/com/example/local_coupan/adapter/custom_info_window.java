package com.example.local_coupan.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.local_coupan.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class custom_info_window implements GoogleMap.InfoWindowAdapter {

    private final View mWindow;
    private final Context mcontext;

    public custom_info_window(Context mcontext) {
        this.mcontext = mcontext;
        mWindow = LayoutInflater.from(mcontext).inflate(R.layout.custom_map_window, null);
    }

    @SuppressLint("SetTextI18n")
    private void rendowWindowText(Marker marker, View view) {

        TextView tvtitle = view.findViewById(R.id.title_window);
        TextView tvbrand = view.findViewById(R.id.brand_window);
        TextView address1 = view.findViewById(R.id.address1_window);
        TextView address2 = view.findViewById(R.id.address2_window);
        TextView city = view.findViewById(R.id.address3_window);

        ImageView img_icon = view.findViewById(R.id.img_coupon_window);
        ImageView location = view.findViewById(R.id.img_location_window);

        tvtitle.setText("Title");
        tvbrand.setText("Brand");
        address1.setText("Address 1");
        address2.setText("Address 2");
        city.setText("City");

        img_icon.setImageResource(R.drawable.logo);
        location.setImageResource(R.drawable.location_image);

    }

    @Nullable
    @Override
    public View getInfoContents(@NonNull Marker marker) {
        rendowWindowText(marker, mWindow);
        return mWindow;
    }

    @Nullable
    @Override
    public View getInfoWindow(@NonNull Marker marker) {
        rendowWindowText(marker, mWindow);
        return mWindow;
    }
}
