package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.local_coupan.databinding.ActivityYucallCouponBinding;

public class Yucall_coupon_activity extends AppCompatActivity {
    ActivityYucallCouponBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityYucallCouponBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

        if (getIntent().getStringExtra("type").equals("1")) {

            String edtTermsDescription1 = sh.getString("edtyucalTermsDescription", "");
            binding.yucallTermsss.setText(edtTermsDescription1);

            binding.imgYucallBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String edtTermsDescription = binding.yucallTermsss.getText().toString();

                    Log.d("viru_budget", edtTermsDescription);
                    myEdit.putString("edtyucalTermsDescription", edtTermsDescription);

                    Log.d("viru_budget2", edtTermsDescription);

                    myEdit.apply();

                    Intent get_terms = new Intent(Yucall_coupon_activity.this, Terms_activity.class);
                    get_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_terms.putExtra("type", "1");
                    get_terms.putExtra("type2", "10");
                    startActivity(get_terms);
                    finish();
                }
            });
        } else if (getIntent().getStringExtra("type").equals("2")) {

            String country = sh.getString("country", "");
            binding.txtLocationName.setText(country);

            binding.imgYucallBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        }
    }
}