
package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.local_coupan.databinding.ActivityLaunchDateBinding;
import com.example.local_coupan.preferences2;

public class Launch_date_activity extends AppCompatActivity {
    ActivityLaunchDateBinding binding;
    preferences2 preferences;
    String launch_flag = "null";

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLaunchDateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences sh1 = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);


        SharedPreferences.Editor myEdit = pref.edit();


        preferences.save(Launch_date_activity.this, preferences.KEY_Type2, String.valueOf(2));

        if (getIntent().getStringExtra("navigate").equals("launch")) {
            Log.d("devi3", "onCreate:" + preferences.get(Launch_date_activity.this, preferences.KEY_Type2));
            if (preferences.get(Launch_date_activity.this, preferences.KEY_Type2).equals(10)) {
                myEdit.putString("launch_year", "");
                myEdit.putString("launch_month", "");
                myEdit.putString("launch_date", "");
                myEdit.putString("launch_time", "");
                myEdit.putString("launch_month_num", "");
            }
            String year = sh.getString("launch_year", "");
            String month = sh.getString("launch_month", "");
            String date = sh.getString("launch_date", "");
            String time = sh.getString("launch_time", "");
            String launch_month_num = sh.getString("launch_month_num", "");

            binding.yearNum.setText(year);
            binding.month.setText(month);
            binding.date.setText(date);
            binding.time.setText(time);

            Log.d("launch_date123", "onCreate: " + year + " " + month + " " + date + " " + time + launch_month_num);

            binding.imgBackLaunchDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    back("launch");
                }
            });
            binding.lloutYear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_year = new Intent(Launch_date_activity.this, select_year_activity.class);
                    choose_year.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_year.putExtra("navigate", "launch");
                    startActivity(choose_year);
                }
            });
            binding.lloutMonth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_month = new Intent(Launch_date_activity.this, select_month_activity.class);
                    choose_month.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_month.putExtra("navigate", "launch");
                    startActivity(choose_month);
                }
            });
            binding.lloutDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_date = new Intent(Launch_date_activity.this, date_activity.class);
                    choose_date.putExtra("navigate", "launch");
                    choose_date.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(choose_date);
                }
            });
            binding.lloutTime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_launch_time = new Intent(Launch_date_activity.this, time_activity.class);
                    choose_launch_time.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_launch_time.putExtra("navigate", "launch");
                    startActivity(choose_launch_time);
                }
            });

        }
        if (getIntent().getStringExtra("navigate").equals("expiry")) {

            String year = sh1.getString("expiry_launch_year", "");
            String monthnu = sh1.getString("expiry_launch_monthnu", "");
            String month = sh1.getString("expiry_launch_month", "");
            String date = sh1.getString("expiry_launch_date", "");
            String time = sh1.getString("expiry_launch_time", "");


            binding.txtTitle.setText("Expiry Date");
            Log.d("devi6", "onCreate: e " + sh1.getString("expiry_launch_time", ""));
            Log.d("devi6", "onCreate: e n " + pref.getString("expiry_launch_time", ""));
            binding.yearNum.setText(year);
            binding.month.setText(month);
            binding.date.setText(date);
            binding.time.setText(time);

            binding.lloutYear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_year = new Intent(Launch_date_activity.this, select_year_activity.class);
                    choose_year.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_year.putExtra("navigate", "expiry");
                    startActivity(choose_year);
                }
            });
            binding.imgBackLaunchDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    back("expiry");
                }
            });
            binding.lloutMonth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_month = new Intent(Launch_date_activity.this, select_month_activity.class);
                    choose_month.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_month.putExtra("navigate", "expiry");
                    startActivity(choose_month);
                }
            });
            binding.lloutDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_expiry_date = new Intent(Launch_date_activity.this, date_activity.class);
                    choose_expiry_date.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_expiry_date.putExtra("navigate", "expiry");
                    startActivity(choose_expiry_date);
                }
            });
            binding.lloutTime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent choose_expiry_time = new Intent(Launch_date_activity.this, time_activity.class);
                    choose_expiry_time.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    choose_expiry_time.putExtra("navigate", "expiry");
                    startActivity(choose_expiry_time);
                }
            });
        }
    }

    public void back(String flag) {
        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();
        if (!binding.yearNum.getText().toString().isEmpty() &&
                !binding.month.getText().toString().isEmpty() &&
                !binding.date.getText().toString().isEmpty() &&
                !binding.time.getText().toString().isEmpty()) {

            Intent get_deal_type = new Intent(Launch_date_activity.this, Coupon_deal_activity.class);
            get_deal_type.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            get_deal_type.putExtra("type", "1");

            if (flag.equals("launch")) {

                preferences.save(Launch_date_activity.this, preferences.KEY_Type2, String.valueOf(4));

                Log.d("viru", "back: " + launch_flag);

                myEdit.putString("flag_val", "from_launch");

                String year = binding.yearNum.getText().toString();
                String month = binding.month.getText().toString();
                String date = binding.date.getText().toString();
                String time = binding.time.getText().toString();

                myEdit.putString("launch_year", year);
                myEdit.putString("launch_month", month);
                myEdit.putString("launch_date", date);
                myEdit.putString("launch_time", time);
                myEdit.apply();
                startActivity(get_deal_type);

            }
            else if (flag.equals("expiry")) {

                preferences.save(Launch_date_activity.this, preferences.KEY_Type2, String.valueOf(5));
                preferences.save(Launch_date_activity.this, preferences.KEY_Type3, String.valueOf(5));
                get_deal_type.putExtra("navigate", "expiry");

                String expiry_year = binding.yearNum.getText().toString();
                String expiry_month = binding.month.getText().toString();
                String expiry_date = binding.date.getText().toString();
                String expiry_time = binding.time.getText().toString();

                myEdit.putString("expiry_launch_year", expiry_year);
//                myEdit.putString("expiry_launch_monthnu", expiry_month);
                myEdit.putString("expiry_launch_month", expiry_month);
                myEdit.putString("expiry_launch_date", expiry_date);
                myEdit.putString("expiry_launch_time", expiry_time);

                Log.d("date_time", "back: " + expiry_year + expiry_month + expiry_date + expiry_time);

                myEdit.apply();
                startActivity(get_deal_type);
            }
        } else {
            Toast.makeText(this, "Please Fill on all Fields", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (binding.txtTitle.getText().equals("Launch Date")) {
            back("launch");
        } else if (binding.txtTitle.getText().equals("Expiry Date")) {
            back("expiry");
        }
    }
}