package com.example.local_coupan.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.local_coupan.databinding.ActivitySelectMarketGroupBinding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class select_market_group_activity extends AppCompatActivity {
    ActivitySelectMarketGroupBinding binding;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectMarketGroupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getIntent().getStringExtra("navigate").equals("market")) {


            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();
            ArrayList groupad = new ArrayList();

            Log.d("TAG123", "onCreate: " + pref.getString("marketGropuArray", "").equals(""));
            if (pref.getString("marketGropuArray", "").equals("")) {

                Log.d("TAG", "onCreate: ");
            } else {
                String marketGropuArray = pref.getString("marketGropuArray", "");
                Log.d("marketGropuArray", "onCreate: " + marketGropuArray);
                String substring_group = marketGropuArray.substring(1, marketGropuArray.length() - 1);
                Log.d("select_group123", "onCreate: " + substring_group);
                String[] select_group = substring_group.split(",");

                for (String s : select_group) {
//                    String select_group123 = select_group[i];

                    if (s.equals("group A")) {
                        binding.truePercentage1.setVisibility(View.VISIBLE);
                        Log.d("selected", "onCreate: A");
                    }
                    if (s.equals("group B")) {
                        binding.truePercentage2.setVisibility(View.VISIBLE);
                        Log.d("selected", "onCreate: B");
                    }
                    if (s.equals("group C")) {
                        binding.truePercentage3.setVisibility(View.VISIBLE);
                        Log.d("selected", "onCreate: C");
                    }
                    if (s.equals("group D")) {
                        binding.truePercentage4.setVisibility(View.VISIBLE);
                        Log.d("selected", "onCreate: D");
                    }
                    if (s.equals("group E")) {
                        binding.truePercentage5.setVisibility(View.VISIBLE);
                        Log.d("selected", "onCreate: E");
                    }
                    Log.d("select_group1234", "onCreate: " + s);
                }
            }

            binding.textViewTitle.setText("Marketing Group");

            binding.lloutGroupA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    groupad.add("group A");
                    binding.truePercentage1.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    groupad.add("group B");
                    binding.truePercentage2.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    groupad.add("group C");
                    binding.truePercentage3.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupD.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    groupad.add("group D");
                    binding.truePercentage4.setVisibility(View.VISIBLE);
                }
            });
            binding.lloutGroupE.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    groupad.add("group E");
                    binding.truePercentage5.setVisibility(View.VISIBLE);
                }

            });
            binding.imgBackGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle args = new Bundle();
                    SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                    SharedPreferences.Editor aaaa = pref.edit();


                    String markeyArrayy = String.valueOf(groupad);
                    Log.d("marketArray 2", "onClick: " + markeyArrayy);
                    Intent get_target = new Intent(select_market_group_activity.this, Target_activity.class);
                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_target.putExtra("type", "1");
                    aaaa.putString("marketGropuArray", markeyArrayy);
                    aaaa.putString("return", "yesm");
                    aaaa.apply();

                    startActivity(get_target);
                    finish();

                }
            });
        } else if (getIntent().getStringExtra("navigate").equals("target_message")) {

            binding.textViewTitle.setText("Message Group");

            binding.lloutGroupA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage1.setVisibility(View.VISIBLE);
                    String group = "Group 1";
                    Log.d("group1", "onClick:  " + group);
                }
            });

            binding.lloutGroupB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage2.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage3.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupD.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage4.setVisibility(View.VISIBLE);
                }

            });
            binding.lloutGroupE.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage5.setVisibility(View.VISIBLE);
                }
            });

            binding.imgBackGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
//                    Intent get_target = new Intent(select_market_group_activity.this, Share_activity.class);
//                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    get_target.putExtra("type", "1");
//                    startActivity(get_target);
//                    finish();
                }
            });
        }
        else if (getIntent().getStringExtra("navigate").equals("share_message")) {

            binding.textViewTitle.setText("Message Group");

            binding.lloutGroupA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage1.setVisibility(View.VISIBLE);
                    String group = "Group 1";
                    Log.d("group1", "onClick:  " + group);
                }
            });

            binding.lloutGroupB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage2.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage3.setVisibility(View.VISIBLE);
                }
            });

            binding.lloutGroupD.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage4.setVisibility(View.VISIBLE);
                }

            });
            binding.lloutGroupE.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    binding.truePercentage5.setVisibility(View.VISIBLE);
                }
            });

            binding.imgBackGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_target = new Intent(select_market_group_activity.this, Share_activity.class);
                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_target.putExtra("type", "1");
                    startActivity(get_target);
                    finish();
                }
            });
        }
    }
}