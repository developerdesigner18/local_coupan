package com.example.local_coupan.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import com.example.local_coupan.ApiInterface;
import com.example.local_coupan.R;
import com.example.local_coupan.RetrofitClient;
import com.example.local_coupan.activity.Add_cupoan.AddCoupan;
import com.example.local_coupan.activity.Add_cupoan.CouponData;
import com.example.local_coupan.databinding.ActivityAddcouponBinding;
import com.example.local_coupan.model.Edit__Coupan.EditData;
import com.example.local_coupan.model.Get_id_vise_data.ID_CouponData;
import com.example.local_coupan.model.id_wise_coupon.IdwiseCoupon;
import com.example.local_coupan.preferences2;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import kotlin.jvm.internal.Intrinsics;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class Addcoupon_activity extends AppCompatActivity {

    MultipartBody.Part part;
    MultipartBody.Part edit_part_1;
    MultipartBody.Part part2;
    preferences2 preferences;
    String finallaunchdate;
    String finallaunchdateexptiry;
    File image;
    ActivityAddcouponBinding binding;
    private final int CAMERA_CODE = 101;
    public int GALLERY_REQ_CODE;
    String image_code = "null";
    public static String BASE_URL_PAYMENT = "http://54.90.77.44:8000/payment/";
    private Bitmap bitmap;
    String base64Image;
    //Uri to store the image uri
    private Uri filePath;
    public Uri imageuri;
    File file;
    JSONArray arraytext = new JSONArray();
    String path;
    float deliveryCost2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddcouponBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String value = getIntent().getStringExtra("type");
        Log.d("devi1", "onCreate: " + value);
        String ids = getIntent().getStringExtra("ids");
        if (getIntent().getStringExtra("type").equals("1")) {

            binding.cardPreviewButton.setVisibility(View.GONE);
            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();
            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
            SharedPreferences.Editor aaaa = pref.edit();


            String marketing = sh.getString("marketing", "");
            String dealtype = sh.getString("deal_dealtype", "");
            String last_image_location = sh.getString("lastimageloaction", "");
            String currency = sh.getString("deal_currency", "");
            String calculation = sh.getString("deal_calculation", "");
            String share = sh.getString("share", "");
            String use = sh.getString("use", "");
            String Description = sh.getString("deal_Description", "");
            String maximumamount = sh.getString("deal_maximumamount", "");
            String regular_price = sh.getString("deal_regular_price", "");
            String offer_price = sh.getString("deal_offer_price", "");
            String launch_deal_year = sh.getString("launch_deal_year", "");
            String launch_deal_month = sh.getString("launch_deal_month", "");
            String launch_deal_date = sh.getString("launch_deal_date", "");
            String launch_deal_time = sh.getString("launch_deal_time", "");
            String expiry_deal_year = sh.getString("expiry_deal_year", "");
            String expiry_deal_month = sh.getString("expiry_deal_month", "");
            String expiry_deal_date = sh.getString("expiry_deal_date", "");
            String expiry_deal_time = sh.getString("expiry_deal_time", "");
            String currentDateandTime1 = sh.getString("currentDateandTime1", "");
            String expriree_times1 = sh.getString("expriree_times", "");
            Log.d("sharred", "onCreate: " + share);


            Log.d("launch_deal_year", "onCreate: " + preferences2.get(Addcoupon_activity.this, preferences2.KEY_Type5));
            if (preferences2.get(Addcoupon_activity.this, preferences2.KEY_Type5).equals("2")) {
                Log.d("launch_deal_year", "onCreate: " + currentDateandTime1);
                Log.d("launch_deal_year", "onCreate: " + expriree_times1);
                String strex[] = expriree_times1.split(" ");
                Log.d("launch_deal_year", "onCreate: " + strex[0] + " m " + strex[1]);
                String exdateformate1[] = strex[0].split("/");
                String exdateformate2[] = strex[1].split(":");
                finallaunchdateexptiry = exdateformate1[2] + "-" + exdateformate1[1] + "-" + exdateformate1[0] + "T" + exdateformate2[0] + ":" + exdateformate2[1] + ":" + exdateformate2[2];
                Log.d("launch_deal_year", "onCreate: n " + finallaunchdate);

                String str[] = currentDateandTime1.split("  ");
                Log.d("launch_deal_year", "onCreate: " + str[0] + " m " + str[1]);
                String dattefor[] = str[0].split("/");
                String dattefor2[] = str[1].split(":");
                finallaunchdate = dattefor[2] + "-" + dattefor[1] + "-" + dattefor[0] + "T" + dattefor2[0] + ":" + dattefor2[1] + ":" + dattefor2[2];
                Log.d("launch_deal_year", "onCreate: n " + finallaunchdate + finallaunchdateexptiry);
            }


            String txt_location_method = sh.getString("txt_location_method_target", "");
            String location_method = sh.getString("method", "");
            String txt_journey_type = sh.getString("txt_journey_type_target", "");
            String txt_journey_method = sh.getString("txt_journey_method_target", "");
//            String txt_time_to_location_type = sh.getString("txt_time_to_location_type_target", "");
            String txt_gender_type = sh.getString("txt_gender_type_target", "");
            String txt_weather_type = sh.getString("txt_weather_type_target", "");
            String get_units = sh.getString("get_units_target", "");
            String get_distance = sh.getString("get_distance_target", "");
            String txt_min_age = sh.getString("txt_min_age_target", "");
            String txt_max_age = sh.getString("txt_max_age_target", "");
            String txt_min_temp = sh.getString("txt_min_temp_target", "");
            String txt_max_temp = sh.getString("txt_max_temp_target", "");
            String termss = sh.getString("edtTermsDescription", "");
            String marketing_Group = sh.getString("marketGropuArray", "");

            String txt_time_to_location_type = sh.getString("D1", "");
            String geofanceDistence = sh.getString("D2", "");

            Log.d("marketGropuArray", "onCreate: " + marketing_Group);


            String add1 = sh.getString("address1", "");
            String add2 = sh.getString("address2", "");
            String tcity = sh.getString("town_city", "");
            String pcode = sh.getString("postcode", "");
            String optime = sh.getString("opening_times", "");
            String latitude = sh.getString("latitude", "");
            String longitude = sh.getString("longitude", "");
            String country = sh.getString("country", "");

            Log.d("devi6", "onCreate: " + add1);
            Log.d("devi6", "onCreate: " + add2);
            Log.d("devi6", "onCreate: " + tcity);
            Log.d("devi6", "onCreate: " + pcode);
            Log.d("devi6", "onCreate: " + optime);
            Log.d("devi6", "onCreate: " + latitude);
            Log.d("devi6", "onCreate: " + longitude);
            Log.d("devi6", "onCreate: " + country);
            String selectedImageUri = sh.getString("selectedImageUri1", "");
            Uri selectedds = Uri.parse(selectedImageUri);
            Log.d("selectedImageUri 4 ", "onCreate: " + selectedImageUri);

            Boolean share1;
//            List<String> myList = new ArrayList<String>(Arrays.asList(marketing_Group.split(",")));
//            Log.d("myList","postdata: "+myList);

            Boolean use1;
            if (share.equals("Yes")) {
                share1 = true;
            } else {
                share1 = false;
            }
            if (use.equals("Yes")) {
                use1 = true;
            } else {
                use1 = false;
            }
            //loaction_data

//            Bundle b = getIntent().getExtras();
//            String final_location = b.getString("Array_location");
//
//            Log.d("final_location", "onCreate: " + final_location);
//            Toast.makeText(this, "location" + " " + final_location, Toast.LENGTH_SHORT).show();


            Log.d("deal_type_data", "onCreate: " + dealtype + " " + currency + " " + calculation + " " + share +
                    " " + use + " " + Description + " " + maximumamount + " " + regular_price + " " + offer_price + " " +
                    launch_deal_year + " " + launch_deal_month + " " + launch_deal_date + " " + launch_deal_time + " "
                    + expiry_deal_year + " " + expiry_deal_month + " " + expiry_deal_date + " " + expiry_deal_time);


            Log.d("target_data", "onCreate: " + txt_location_method + " " + txt_journey_type + " " + txt_journey_method + " " + txt_time_to_location_type +
                    " " + txt_gender_type + " " + txt_weather_type + " " + txt_min_age + " " + txt_max_age + " " + txt_min_temp + " " +
                    txt_max_temp + " " + get_units + " " + get_distance);

            String detroye = preferences.get(Addcoupon_activity.this, preferences.KEY_Detroye);
            Log.d("detroye", "onCreate: ");
            if (detroye.equals("0")) {
                preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.KEY_Bitmap, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.KEY_Part, String.valueOf(""));
//                preferences.save(Addcoupon_activity.this, preferences.KEY_File, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(""));
                preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(""));
                Log.d("saveimag", "onCreate: j");
            }
            String title = preferences.get(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE);
            String brand1 = preferences.get(Addcoupon_activity.this, preferences.KEY_BRAND_NAME);
            String product1 = preferences.get(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME);
            String deliveryCost11 = preferences.get(Addcoupon_activity.this, preferences.Key_delevary);
            String part5 = preferences.get(Addcoupon_activity.this, preferences.KEY_Part);
            String filesss = preferences.get(Addcoupon_activity.this, preferences.KEY_File);
            String bitmap5 = preferences.get(Addcoupon_activity.this, preferences.KEY_Bitmap);

            Log.d("saveimag", "onCreate: " + bitmap5);
//            bitmap = bitmap5;
            Log.d("deliveryCost11", "onCreate: " + deliveryCost11);
            if (deliveryCost11.equals("")) {
                deliveryCost2 = 0;
            } else {
                deliveryCost2 = Float.parseFloat(deliveryCost11);
            }

            preferences.save(Addcoupon_activity.this, preferences.KEY_Detroye, String.valueOf("2"));

            String destroye2 = preferences.get(Addcoupon_activity.this, preferences.Key_delevary);
            binding.txtDeliveryCharge.setText(destroye2);
            binding.edtEnterTitle.setText(title);
            binding.edtEnterShop.setText(brand1);
            binding.edtEnterProduct.setText(product1);
            binding.edtEnterProduct.setText(product1);

            part = createpart(filesss);
            part2 = createpart2(last_image_location);

            Bitmap bt5 = StringToBitMap(bitmap5);

            binding.imgFromUser.setImageBitmap(bt5);
            Log.d("saveimag m ", "onCreate: " + bt5);
            String alloverbudget = sh.getString("edt_enter_overallbudget", "");
            String maximumbudget = sh.getString("edt_entermaximumbudget", "");
            if (getIntent().getStringExtra("type2").equals("10")) {

                binding.txtBudgetPrice.setText("");

            } else if (getIntent().getStringExtra("type2").equals("2")) {

                binding.txtBudgetPrice.setText(alloverbudget);
            }

            binding.btnCopy.setOnClickListener(v -> {
                Log.d("jsonArray c ", "onCreate: " + part);
//                String final_location = sh.getString("Array_location", "");
//                String result22 = final_location.substring(1, final_location.length() - 1);
//                Log.d("myList", "postdata: " + result22);
//
//                List<String> myList = new ArrayList<String>(Arrays.asList(result22.split(",")));
//                ArrayList<String> strinfArraylist = new ArrayList<String>(myList);
//
//                ArrayList<String> arrayobkects = new ArrayList<>();
//                arrayobkects.add(result22);
//
//                Log.d("myList", "postdata: " + arrayobkects);
//                Log.d("deviaddd 1", "onCreate: " + final_location);

            });
            binding.btnNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_pay = new Intent(Addcoupon_activity.this, Payment_method.class);
                    String title = binding.edtEnterTitle.getText().toString();
                    String alloverbudget = binding.txtBudgetPrice.getText().toString();
                    myEdit.putString("title", title);
                    myEdit.putString("alloverbudget", alloverbudget);
                    myEdit.apply();
                    get_pay.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    get_pay.putExtra("flag", "null");
                    startActivity(get_pay);

                }
            });
            binding.btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String ids = preferences.get(Addcoupon_activity.this, preferences.KEY_ID);
                    Log.d("bitmapimage part", "onClick: " + part);
//                    String final_location = sh.getString("Array_location", "");
//                    String result22 = final_location.substring(1, final_location.length() - 1);
//                    Log.d("myList", "postdata: " + result22);
//                    List<String> myList = new ArrayList<String>(Arrays.asList(result22.split(",")));
//                    ArrayList<String> strinfArraylist = new ArrayList<String>(myList);
//
//                    ArrayList<String> arrayobkects = new ArrayList<>();
//                    arrayobkects.add(result22);
//
//                    Log.d("myList", "postdata: " + arrayobkects);
//                    Log.d("deviaddd 1", "onCreate: " + final_location);
// String imageuri =  getIntent().getStringExtra("Username");
//                   String imageuri =  "content://com.android.providers.media.documents/document/image%3A2442";
//
//                    ArrayList<String> arrayobkects = new ArrayList<>();
//                    arrayobkects.add(result22);
//
//                    Log.d("myList", "postdata: " + arrayobkects);
//                    Log.d("deviaddd 1", "onCreate: " + final_location);
//
////                   String imageuri =  getIntent().getStringExtra("Username");
////                   String imageuri =  "content://com.android.providers.media.documents/document/image%3A2442";
////
////
////                    Log.d("bitmapimage f ", "onClick: " + imageuri);
////
////
////                        Context context = Addcoupon_activity.this;
////                        Intrinsics.checkNotNullExpressionValue(context, "applicationContext");
////                        File fileDir = context.getFilesDir();
////                        File file = new File(fileDir, "image.png");
////                        ContentResolver var8 = getContentResolver();
////                        Uri var10001 = Uri.parse(imageuri);
////                        if (var10001 == null) {
////                            Intrinsics.throwUninitializedPropertyAccessException("imageuri");
////                        }
////
////                        InputStream inputStream = null;
////                        try {
////                            inputStream = var8.openInputStream(var10001);
////                            FileOutputStream outputStream = new FileOutputStream(file);
////                        } catch (FileNotFoundException e) {
////                            e.printStackTrace();
////                        }
////                        Intrinsics.checkNotNull(inputStream);
//////                        ByteStreamsKt.copyTo$default(inputStream, (OutputStream)outputStream, 0, 2, (Object)null);
////                        RequestBody requestBody = RequestBody.Companion.create(file, MediaType.Companion.parse("image/*"));
////                        MultipartBody.Part part = MultipartBody.Part.Companion.createFormData("couponImage", file.getName(), requestBody);
////                        Log.d("bitmapimage m ", "upload: " + file);
////                        Log.d("bitmapimage  m ", "upload: " + part);
//
////                    postdata(title, brand1, brand1, product1, product1, "6", "7", 8, "currency", 10,
////                            11, true, true, "14", "15", "2016-05-18T16:00:00.000+00:00", "launch_deal_time", "2016-05-18T16:00:00.000+00:00",
////                            "expiry_deal_time", true, true, 24, "23", "24", "25", "26", "27", "28", "29", "30"
////                            , "31", "32", "33", "txt_journey_type", "36", 37, 38, "txt_gender_type"
////                            , 40, 41, 42, "43", 44, true, "46", "47", "48", 49, "50"
////                            , "txt_journey_type", "get_units", "termss", "txt_weather_type", "txt_time_to_location_type", 56.00f, 57.99d, 58, "calculation", 60, 61, "63", ids, "Description", marketing_Group, final_location, part);
////                    postdata(title, brand1, brand1, product1, product1, dealtype, currency, 8,  10,
////                            11,  "14", "15", "2016-05-18T16:00:00.000+00:00", launch_deal_time, "2016-05-18T16:00:00.000+00:00",
////                            expiry_deal_time, share1, use1, Integer.valueOf(maximumamount), "23", "24", "25", "26", "27", "28", "", ""
////                            , "31", "32", geofanceDistence, txt_journey_type, "36", Integer.valueOf(txt_min_age), Integer.valueOf(txt_max_age), txt_gender_type
////                            , Integer.valueOf(txt_max_temp), Integer.valueOf(txt_min_temp), Integer.valueOf(alloverbudget), "43", 44, true, "46", "47", "48", geofanceDistence, location_method
////                            , txt_journey_type, get_units, termss, txt_weather_type, txt_time_to_location_type, 56.00f, 57.99d, 58, calculation, Integer.valueOf(alloverbudget), Integer.valueOf(maximumbudget), "63",
////                            ids, Description, marketing_Group, final_location, part,
////                            Integer.valueOf(regular_price),Integer.valueOf(offer_price));
                    Log.d("finallaunchdate", "onClick: " + finallaunchdate + " " + finallaunchdateexptiry);

                    if (!binding.edtEnterTitle.getText().toString().isEmpty() &&
                            !binding.edtEnterShop.getText().toString().isEmpty() &&
                            !binding.edtEnterProduct.getText().toString().isEmpty() &&
                            !binding.txtDeliveryCharge.getText().toString().isEmpty() &&
                            !preferences.get(Addcoupon_activity.this, preferences.KEY_Bitmap).equals("") &&
                            dealtype != null
                            && currency != null
                            && finallaunchdate != null
                            && finallaunchdateexptiry != null
                            && share1 != null
                            && use1 != null
                            && !maximumamount.equals("")
                            && !add1.equals("")
                            && !add2.equals("")
                            && !tcity.equals("")
                            && !pcode.equals("")
                            && !optime.equals("")
//                            && !geofanceDistence.equals("")
//                            && !txt_journey_type.equals("")
                            && !txt_gender_type.equals("")
//                            && !get_units.equals("")
                            && !termss.equals("")
                            && !txt_weather_type.equals("")
//                            && !txt_time_to_location_type.equals("")
                            && !calculation.equals("")
                            && !Description.equals("")
                            && !marketing_Group.equals("")
                            && !part.equals("")
                            && !part2.equals("")
                            && !latitude.equals("")
                            && !longitude.equals("")
                            && !txt_min_age.equals("")
                            && !txt_max_age.equals("")
                            && !txt_max_temp.equals("")
                            && !txt_min_temp.equals("")
                            && !alloverbudget.equals("")
                            && !maximumbudget.equals("")
                            && !regular_price.equals("")
                            && !offer_price.equals("")
//                            && !alloverbudget.equals("")
                    ) {

                        String market_group = marketing_Group.substring(1, marketing_Group.length() - 1);
                        Log.d("marketGropuArray", "onCreate: " + market_group);
                        binding.progressbarList.setVisibility(View.VISIBLE);

                        postdata(title, brand1, brand1, product1, product1, dealtype, currency, finallaunchdate,
                                "0000-00-00T00:00:00", finallaunchdateexptiry,
                                "0000-00-00T00:00:00", share1, use1, Integer.valueOf(maximumamount), add1, add2,
                                tcity, tcity, pcode, optime, "0", geofanceDistence, txt_journey_type,
                                Integer.valueOf(txt_min_age), Integer.valueOf(txt_max_age), txt_gender_type,
                                Integer.valueOf(txt_max_temp), Integer.valueOf(txt_min_temp), Integer.valueOf(alloverbudget),
                                get_units, 0, location_method, get_units, termss, txt_weather_type, txt_time_to_location_type,
                                calculation, Integer.valueOf(alloverbudget), Integer.valueOf(maximumbudget), country,
                                ids, Description, market_group, part, Integer.valueOf(regular_price), Integer.valueOf(offer_price),
                                true, Float.valueOf(alloverbudget), part2, deliveryCost2, longitude, latitude);


                    } else {

                        Toast.makeText(Addcoupon_activity.this, "Please Fill Every Fields", Toast.LENGTH_SHORT).show();

                    }
//                    postdata("Adidas", "brand", "3", "product", "5", "6", "7", 8, 123, 123,
//                            true, true, "13", "14", "edt_date_time_picker", "16", "edtExpiryDateTime", "18",
//                            true, true, 123, "edt_address1", "edt_address2", "edt_Town_city", "edt_Town_city", "edt_postcode", "edt_opningtimes", "28", "29", "30"
//                            , "32", "33", "txt_journey_method", "txt_time_to_location_type", 12, 21, "ksnfgk", 12
//                            , 10, "41", "currency_type", 43, "44", 45, true, "47", 48, "49", "50"
//                            , "51", "52", "53", 54.356f, "55", 56.99d, 57, 58, "59",
//                            60, "61", "62");
                }
            });

            binding.lloutDeal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
//                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    Intent get_deal = new Intent(Addcoupon_activity.this, Coupon_deal_activity.class);
                    get_deal.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_deal.putExtra("type", "1");
                    get_deal.putExtra("type2", "10");
                    get_deal.putExtra("navigate", "null");
                    get_deal.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_deal);
                }
            });//done

            binding.lloutLocation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));

                    Intent get_location = new Intent(Addcoupon_activity.this, location_activity.class);
                    get_location.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_location.putExtra("type", "1");
                    get_location.putExtra("type2", "10");
                    get_location.putExtra("Array", String.valueOf(arraytext));
                    get_location.putExtra("navigate", "111");

                    startActivity(get_location);
                }
            });//done

            binding.imgBackCouponList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_main = new Intent(Addcoupon_activity.this, MainActivity.class);
                    get_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_main);
                    finish();
                }
            });

            binding.lloutTarget.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));

                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));

                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));

                    Intent get_target = new Intent(Addcoupon_activity.this, Target_activity.class);
                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_target.putExtra("type", "1");
                    get_target.putExtra("type2", "10");
//                    get_target.putExtra("return", "no");
                    aaaa.putString("return", "no");

                    startActivity(get_target);
                }
            });//done

            binding.lloutbudget.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));
                    Intent get_allbudget = new Intent(Addcoupon_activity.this, overallbudget_activity.class);
                    get_allbudget.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_allbudget.putExtra("type", "1");
                    get_allbudget.putExtra("type2", "10");
                    startActivity(get_allbudget);
                }
            });//done

            binding.cardPreviewButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));
                    Intent get_preview = new Intent(Addcoupon_activity.this, Coupon_details.class);
                    get_preview.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_preview);
                }
            });

            binding.llouttearms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));
                    Intent get_terms = new Intent(Addcoupon_activity.this, Terms_activity.class);
                    get_terms.putExtra("type", "1");
                    get_terms.putExtra("type2", "10");
                    get_terms.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_terms);

                }
            });

            binding.lloutImgFromUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    String budget123 = binding.txtBudgetPrice.getText().toString();

                    preferences.save(Addcoupon_activity.this, preferences.Key_budget, String.valueOf(budget123));

                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    if (Build.VERSION.SDK_INT >= 23) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            selectImage();
                        } else {
                            ActivityCompat.requestPermissions(Addcoupon_activity.this, new String[]{
                                    Manifest.permission.CAMERA}, 1);
                            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
//                                Toast.makeText(Addcoupon_activity.this, "if", Toast.LENGTH_SHORT).show();
                                image_code = "add";
                                Log.d("devi1", "onClick: add " + image_code);
//                                 Intent intent = new Intent(Addcoupon_activity.this, Image_set_Activity.class);
//                                startActivity(intent);
                                selectImage();
                            } else {
                                Log.d("devi1", "onClick: 2 else");
//                                Toast.makeText(Addcoupon_activity.this, "else", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        Log.d("devi1", "onClick: 1 else");
                    }
                }
            });

        } else if (getIntent().getStringExtra("type").equalsIgnoreCase("2")) {

            SharedPreferences pref = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
            SharedPreferences.Editor myedit = pref.edit();
            SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

            String title = sh.getString("title", "");
            String Copon_image = sh.getString("Copon_image", "");
            String brand = sh.getString("brand", "");
            String Product = sh.getString("Product", "");
            String budget = sh.getString("budget", "");
            String overall_budget = sh.getString("overall_budget", "");
            String delivery_cost = sh.getString("delivery_cost", "");

            URL url = null;
            try {
                url = new URL(Copon_image);
                Log.d("url123", "onCreate: " + url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            Picasso.get().load(String.valueOf(url)).into(binding.imgFromUser);
//            File edit_image_file = new File(url.getFile());
//            Log.d("url123", "onCreate: " + edit_image_file);
//            Log.d("url123", "onCreate: " + edit_image_file.getName());
//            String filePath = edit_image_file.getPath();
//            Bitmap bitmap = BitmapFactory.decodeFile(filePath);
//            binding.imgFromUser.setImageBitmap(bitmap);
//
//            String pngg = ".JPEG";

//            File ful_file = bitmapToFile(getApplicationContext(),bitmap,pngg);
//            String st_file = String.valueOf(ful_file);
//            myedit.putString("edit_img_file", st_file);
//            myedit.apply();

//            editcreatepart(st_file);
//            edit_part_1 = editcreatepart(st_file);
//
//            Log.d("edit_part_1", "onCreate: " + edit_part_1);

            binding.edtEnterTitle.setText(title);
            binding.edtEnterProduct.setText(Product);
            binding.edtEnterShop.setText(brand);
            binding.txtBudgetPrice.setText(overall_budget);
            binding.txtDeliveryCharge.setText(delivery_cost);

            binding.edtEnterTitle.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String edit_title = binding.edtEnterTitle.getText().toString();
                    myedit.putString("title", edit_title);
                    myedit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtEnterShop.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String brand = binding.edtEnterShop.getText().toString();
                    myedit.putString("brand", brand);
                    myedit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtEnterProduct.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String Product = binding.edtEnterProduct.getText().toString();
                    myedit.putString("Product", Product);
                    myedit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.txtDeliveryCharge.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String delivery_cost = binding.txtDeliveryCharge.getText().toString();
                    myedit.putString("delivery_cost", delivery_cost);
                    myedit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            if (getIntent().getStringExtra("type2").equalsIgnoreCase("20")) {

                String ids1 = sh.getString("ids12", "");
                id_vise_coupon_data(ids1);

            }


            binding.btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    binding.progressbarList.setVisibility(View.VISIBLE);
                    binding.mainLinear.setVisibility(View.GONE);

                    String finalimage = preferences.get(Addcoupon_activity.this, preferences.KEY_PRODUCT_Image);
                    Log.d("finalimage", "onCreate: " + finalimage);
                    String filesss = preferences.get(Addcoupon_activity.this, preferences.KEY_File);

                    SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

                    //add coupon data
                    String title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String Product = binding.edtEnterProduct.getText().toString();

                    String Copon_image = sh.getString("Copon_image", "");
                    String budget = sh.getString("budget", "");
                    String overall_budget = sh.getString("overall_budget", "");
                    String delivery_cost = sh.getString("delivery_cost", "");
                    String edt_entermaximumbudget = sh.getString("edt_entermaximumbudget", "");
                    String userid = sh.getString("userid", "");

                    //deal data
                    String deal_dealtype = sh.getString("dealtype", "");
                    String deal_currency = sh.getString("currency", "");
                    String deal_calculation = sh.getString("calculation", "");
                    String deal_share = sh.getString("share", "");
                    String deal_use = sh.getString("use", "");
                    String deal_Description = sh.getString("description", "");
                    String deal_regular_price = sh.getString("regular_price", "");
                    String deal_offer_price = sh.getString("offer_price", "");
                    String launch_deal_year = sh.getString("launch_deal_year", "");
                    String deal_maximumamount = sh.getString("maximum_redumption", "");
                    String launch_deal_month = sh.getString("deal_dealtype", "");
                    String launch_deal_date = sh.getString("launch_deal_month", "");
                    String launch_deal_time = sh.getString("final_launch_time", "");
                    String expiry_deal_year = sh.getString("deal_dealtype", "");
                    String expiry_deal_month = sh.getString("expiry_deal_year", "");
                    String expiry_deal_date = sh.getString("expiry_deal_date", "");
                    String expiry_deal_time = sh.getString("final_expiry_time", "");
                    String expriree_times = sh.getString("exprirydate", "");
                    String launchdate = sh.getString("launchdate", "");

                    boolean share = true;
                    if (deal_share.equals("Yes")) {
                        share = true;
                    } else if (deal_share.equals("No")) {
                        share = true;
                    }

                    boolean Use = true;
                    if (deal_use.equals("Yes")) {
                        Use = true;
                    } else if (deal_use.equals("No")) {
                        Use = true;
                    }

                    //tareget data
                    String txt_location_method_target = sh.getString("method", "");
                    String txt_time_to_location_type = sh.getString("journeyTime", "");
                    String txt_gender_type_target = sh.getString("gender", "");
                    String txt_weather_type_target = sh.getString("weather", "");
                    String txt_min_age_target = sh.getString("miiin", "");
                    String txt_max_age_target = sh.getString("maxxxx", "");
                    String txt_min_temp_target = sh.getString("tempmin", "");
                    String txt_max_temp_target = sh.getString("tempmax", "");
                    String get_units_target = sh.getString("units", "");
                    String get_distance = sh.getString("distancenum", "");
                    String txt_journey_method_target = sh.getString("journey", "");

                    //terms data

                    String get_terms = sh.getString("terms", "");

                    //location data

                    String address1 = sh.getString("address1", "");
                    String address2 = sh.getString("address2", "");
                    String town_city = sh.getString("town_city", "");
                    String postcode = sh.getString("postcode", "");
                    String opening_times = sh.getString("opening_times", "");
                    String latitude = sh.getString("latitude", "");
                    String longitude = sh.getString("longitude", "");
                    String country = sh.getString("country", "");

                    Log.d("editdata", "onCreate: " + deal_dealtype + " " + deal_currency + " " +
                            deal_calculation + " " + deal_share + " " + deal_use + " " + deal_Description + " " +
                            deal_regular_price + " " + " " + deal_offer_price + " " + launch_deal_year + " " +
                            launch_deal_month + " " + launch_deal_date + " " + launch_deal_time + " " + expiry_deal_year +
                            " " + expiry_deal_month + " " + expiry_deal_date + " " + deal_maximumamount + " " + expiry_deal_time +
                            " " + expriree_times + " " + launchdate);

                    Log.d("editdata", "onCreate: " + txt_location_method_target + " " +
                            txt_time_to_location_type + " " + txt_gender_type_target + " " + txt_weather_type_target + " " + txt_min_age_target + " " +
                            txt_max_age_target + " " + txt_min_temp_target + " " + txt_max_temp_target + " " +
                            get_units_target + " " + get_distance);

                    Log.d("editdata", "onCreate: " + address1 + " " + address2 + " " +
                            town_city + " " + postcode + " " + opening_times + " " + latitude + " " +
                            longitude + " " + country);

                    Log.d("editdata", "onCreate: " + get_terms);

                    part = createpart(filesss);
                    part2 = createpart2(filesss);

                    Log.d("get_distance", "onClick: " + get_distance);


                    EditData2(title, brand, brand, Product, Product,
                            deal_dealtype, deal_currency, "2016-05-18T16:00:00.000+00:00", "10:30",
                            "2016-05-18T16:00:00.000+00:00", "10:40", share, Use, Integer.valueOf(deal_maximumamount),
                            address1, address2, town_city, town_city, postcode,
                            opening_times, "message_group", get_distance,
                            txt_journey_method_target, Integer.valueOf(txt_min_age_target), Integer.valueOf(txt_max_age_target), txt_gender_type_target, Integer.valueOf(txt_max_temp_target), Integer.valueOf(txt_min_temp_target),
                            Integer.valueOf(overall_budget), get_units_target, 0, txt_location_method_target,
                            get_units_target, get_terms, txt_weather_type_target, txt_time_to_location_type,
                            deal_calculation, Integer.valueOf(overall_budget), Integer.valueOf(edt_entermaximumbudget), country, userid
                            , deal_Description, "marketiggroup", Integer.valueOf(deal_regular_price), Integer.valueOf(deal_offer_price), true, Integer.valueOf(overall_budget),
                            Float.valueOf(delivery_cost), longitude, latitude);
                }
            });
            binding.lloutDeal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    Log.d("devi3", "onClick: " + coupon_title + " " + brand + " " + product);
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    Intent get_deal = new Intent(Addcoupon_activity.this, Coupon_deal_activity.class);
                    get_deal.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_deal.putExtra("type", "2");
                    startActivity(get_deal);
                }
            });
            binding.lloutLocation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    Intent get_location = new Intent(Addcoupon_activity.this, location_activity.class);
                    get_location.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_location.putExtra("type", "2");
                    startActivity(get_location);
                }
            });//done
            binding.lloutTarget.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    Intent get_target = new Intent(Addcoupon_activity.this, Target_activity.class);
                    get_target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_target.putExtra("type", "2");
                    get_target.putExtra("type2", "20");
                    startActivity(get_target);
                }
            });//done
            binding.llouttearms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String coupon_title = binding.edtEnterTitle.getText().toString();
                    String brand = binding.edtEnterShop.getText().toString();
                    String product = binding.edtEnterProduct.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE, String.valueOf(coupon_title));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_BRAND_NAME, String.valueOf(brand));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME, String.valueOf(product));
                    String delevery = binding.txtDeliveryCharge.getText().toString();
                    preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

                    Intent get_terms2 = new Intent(Addcoupon_activity.this, Terms_activity.class);
                    get_terms2.putExtra("type", "2");
                    get_terms2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_terms2);
                }
            });
            binding.cardPreviewButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_preview = new Intent(Addcoupon_activity.this, Coupon_details.class);
                    get_preview.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_preview.putExtra("type", "2");
                    startActivity(get_preview);
                }
            });
            binding.imgBackCouponList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_main = new Intent(Addcoupon_activity.this, MainActivity.class);
                    get_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(get_main);
                    finish();
                }
            });
            binding.lloutImgFromUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
//                            Intent intent = new Intent(Addcoupon_activity.this, Image_set_Activity.class);
//                            startActivity(intent);
                            selectImage();
                        } else {
                            ActivityCompat.requestPermissions(Addcoupon_activity.this, new String[]{
                                            Manifest.permission.CAMERA},
                                    1);
                            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                image_code = "edit";
//                                Intent intent = new Intent(Addcoupon_activity.this, Image_set_Activity.class);
//                                startActivity(intent);
                                selectImage();
                            }
                        }
                    }
                }
            });

        } else {
            String title12 = preferences.get(Addcoupon_activity.this, preferences.KEY_COUPON_TITLE);
            String brand12 = preferences.get(Addcoupon_activity.this, preferences.KEY_BRAND_NAME);
            String product12 = preferences.get(Addcoupon_activity.this, preferences.KEY_PRODUCT_NAME);
            String delevery = binding.txtDeliveryCharge.getText().toString();
            preferences.save(Addcoupon_activity.this, preferences.Key_delevary, String.valueOf(delevery));

            Log.d("devi3", "onCreate: " + title12 + " " + brand12 + " " + product12);
            binding.edtEnterTitle.setText(title12);
            binding.edtEnterShop.setText(brand12);
            binding.edtEnterProduct.setText(product12);
        }
    }


    private void postdata(String couponTitle, String brand, String shop, String product, String service, String dealType
            , String currency,
                          String launchDate, String launchTime, String expiryDate, String expiryTime, Boolean shared,
                          Boolean singleUse, Integer maximumRedemptions, String address1, String address2, String town,
                          String city, String postcode, String openingTimes,
                          String messageGroup, String distance, String journeyType,
                          Integer ageMin, Integer ageMax, String gender, Integer overTemperature, Integer underTemperature,
                          Integer projectBudget, String distanceUnits, Integer distancenum, String locationType,
                          String geofenceUnit, String terms, String weather, String timeToLocation,
                          String showCalculations, Integer overallBudget,
                          Integer maximumDailybudget, String country,
                          String userId, String description, String marketingGroup, MultipartBody.Part couponImage,
                          Integer normalPrice, Integer offerPrice, Boolean playPauseStatus, Float budget, MultipartBody.Part addressImage, Float deliveryCost, String longitude, String latitude) {
        ApiInterface apiInterface = RetrofitClient.getClient().create(ApiInterface.class);

//        String result = location.substring(1, location.length() - 1);
//        Log.d("myList", "postdata: " + marketingGroup);
//
//        String result22 = marketingGroup.substring(1, marketingGroup.length() - 1);
//        Log.d("myList", "postdata: " + result22);
//        List<String> myList = new ArrayList<String>(Arrays.asList(marketingGroup.split(",")));
//        Log.d("myList", "postdata: " + myList);
//        Log.d("viru10", "postdata: " + "coupon_title"  + brand + pruduct + normalPrice + offerPrice + playPauseStatus);


//        location.replaceAll("[]//", "");
//        List<String> lastgroup = Collections.singletonList(marketingGroup);
//        Log.d("lastttone 1", "postdata: " + marketingGroup + "  " + location);
////        Log.d("lastttone 2", "postdata: "+lastgroup + "  "+lastlolcation);
////        String list = Arrays.toString(lastlolcation.toArray()).replace("[", "").replace("]", "");
////        Log.d("lastttone 3", "postdata: "+list);

//        List<Object> lastlolcation2 = Collections.singletonList(location);
//        String result = location.substring(1, location.length() - 1);
//        List<Object> lastlolcation = Collections.singletonList(result);
//        Log.d("lastttone ", "postdata: " + result);
//        Log.d("lastttone ", "postdata: " + lastlolcation);
//        Log.d("lastttone ", "postdata: " + lastlolcation2);

        RequestBody couponTitle1 = RequestBody.create(MediaType.parse("multipart/form-data"), couponTitle);
        RequestBody brand1 = RequestBody.create(MediaType.parse("multipart/form-data"), brand);
        RequestBody shop1 = RequestBody.create(MediaType.parse("multipart/form-data"), shop);
        RequestBody product1 = RequestBody.create(MediaType.parse("multipart/form-data"), product);
        RequestBody service1 = RequestBody.create(MediaType.parse("multipart/form-data"), service);
        RequestBody dealType1 = RequestBody.create(MediaType.parse("multipart/form-data"), dealType);
//        RequestBody offerText1 = RequestBody.create(MediaType.parse("multipart/form-data"), offerText);
//        RequestBody percentageDiscount1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(percentageDiscount));

        RequestBody currency1 = RequestBody.create(MediaType.parse("multipart/form-data"), currency);
//        RequestBody priceSaving1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(priceSaving));
//        RequestBody percentageSaving1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(percentageSaving));
//        RequestBody longProd1 = RequestBody.create(MediaType.parse("multipart/form-data"), longProd);
//        RequestBody serText1 = RequestBody.create(MediaType.parse("multipart/form-data"), serText);
        RequestBody launchDate1 = RequestBody.create(MediaType.parse("multipart/form-data"), launchDate);
        RequestBody launchTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), launchTime);
        RequestBody expiryDate1 = RequestBody.create(MediaType.parse("multipart/form-data"), expiryDate);

        RequestBody expiryTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), expiryTime);
        RequestBody shared1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(shared));
        RequestBody singleUse1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(singleUse));
        RequestBody maximumRedemptions1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(maximumRedemptions));
        RequestBody address11 = RequestBody.create(MediaType.parse("multipart/form-data"), address1);
        RequestBody address21 = RequestBody.create(MediaType.parse("multipart/form-data"), address2);

        RequestBody town1 = RequestBody.create(MediaType.parse("multipart/form-data"), town);
        RequestBody city1 = RequestBody.create(MediaType.parse("multipart/form-data"), city);
        RequestBody postcode1 = RequestBody.create(MediaType.parse("multipart/form-data"), postcode);
        RequestBody openingTimes1 = RequestBody.create(MediaType.parse("multipart/form-data"), openingTimes);
//        RequestBody message1 = RequestBody.create(MediaType.parse("multipart/form-data"), message);
//        RequestBody market1 = RequestBody.create(MediaType.parse("multipart/form-data"), market);
//        RequestBody profile1 = RequestBody.create(MediaType.parse("multipart/form-data"), profile);
        RequestBody messageGroup1 = RequestBody.create(MediaType.parse("multipart/form-data"), messageGroup);
        RequestBody distance1 = RequestBody.create(MediaType.parse("multipart/form-data"), distance);

        RequestBody journeyType1 = RequestBody.create(MediaType.parse("multipart/form-data"), journeyType);
//        RequestBody journeyTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), journeyTime);
        RequestBody ageMin1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(ageMin));
        RequestBody ageMax1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(ageMax));
        RequestBody gender1 = RequestBody.create(MediaType.parse("multipart/form-data"), gender);
        RequestBody overTemperature1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(overTemperature));
        RequestBody underTemperature1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(underTemperature));

        RequestBody projectBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(projectBudget));
//        RequestBody projectCurrency1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(projectCurrency));
//        RequestBody dailyBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(dailyBudget));
//        RequestBody playPauseStatus1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(playPauseStatus));
//        RequestBody mapPin1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(mapPin));
//        RequestBody journey1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(journey));
        RequestBody distanceUnits1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(distanceUnits));
        RequestBody distancenum1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(distancenum));

        RequestBody locationType1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(locationType));
//        RequestBody journeyTyep1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(journeyTyep));
        RequestBody geofenceUnit1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(geofenceUnit));
        RequestBody terms1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(terms));
        RequestBody weather1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(weather));
        RequestBody timeToLocation1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(timeToLocation));
//        RequestBody budget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(budget));

//        RequestBody deliveryCost1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deliveryCost));
//        RequestBody deal1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deal));
        RequestBody showCalculations1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(showCalculations));
        RequestBody overallBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(overallBudget));
        RequestBody maximumDailybudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(maximumDailybudget));
        RequestBody country1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(country));
        RequestBody userId1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(userId));
        RequestBody description1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(description));
        RequestBody lastgroup1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(marketingGroup));
//        RequestBody lastlolcation21 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(location));

        RequestBody normalPrice1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(normalPrice));
        RequestBody offerPrice1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(offerPrice));
        RequestBody playPauseStatus1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(playPauseStatus));
        RequestBody budget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(budget));
        RequestBody deliveryCost1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deliveryCost));
        RequestBody longitude1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(longitude));
        RequestBody latitude1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(latitude));


        Call<AddCoupan> call = apiInterface.add_coupon(couponTitle1, brand1, shop1, product1, service1, dealType1,
                currency1, launchDate1, launchTime1, expiryDate1,
                expiryTime1, shared1, singleUse1, maximumRedemptions1, address11, address21
                , town1, city1, postcode1, openingTimes1, messageGroup1, distance1,
                journeyType1, ageMin1, ageMax1, gender1, overTemperature1, underTemperature1,
                projectBudget1, distanceUnits1, distancenum1,
                locationType1, geofenceUnit1, terms1, weather1, timeToLocation1
                , showCalculations1, overallBudget1, maximumDailybudget1, country1, userId1, description1,
                lastgroup1,
                edit_part_1, normalPrice1, offerPrice1, playPauseStatus1, budget1, part2, deliveryCost1, longitude1, latitude1);

        call.enqueue(new Callback<AddCoupan>() {


            @Override
            public void onResponse(@NonNull Call<AddCoupan> call, @NonNull Response<AddCoupan> response) {

                binding.progressbarList.setVisibility(View.INVISIBLE);
                Log.d("devi1A", "onResponse: " + response.raw());

                if (response.code() == 200) {

                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();


                    if (response.body().getCouponData() != null) {
                        CouponData data = response.body().getCouponData();

                        myEdit.putString("pay_uid", data.getUserId());
                        myEdit.putString("pay_getid", data.getId());
                        myEdit.putString("pay_titel", data.getCouponTitle());
                        myEdit.putFloat("pay_budget", data.getOverallBudget());
                        myEdit.apply();
                        add_payment();

                    } else {
                        Log.d("devi1A", "onResponse: Your Data is null");
                        Toast.makeText(Addcoupon_activity.this, "Your Data is null", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Log.d("devi1A", "onResponse: 1 else");
//                    Toast.makeText(Addcoupon_activity.this, " 1 else" + response.raw(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<AddCoupan> call, @NonNull Throwable t) {
                Toast.makeText(Addcoupon_activity.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
                Log.d("devi1A", "onFailure: " + t);

            }
        });
    }

    private void EditData2(String couponTitle, String brand, String shop, String product, String service, String dealType, String currency,
                           String launchDate, String launchTime, String expiryDate, String expiryTime, Boolean shared,
                           Boolean singleUse, Integer maximumRedemptions, String address1, String address2, String town,
                           String city, String postcode, String openingTimes,
                           String messageGroup, String distance, String journeyType,
                           Integer ageMin, Integer ageMax, String gender, Integer overTemperature, Integer underTemperature,
                           Integer projectBudget, String distanceUnits, Integer distancenum, String locationType,
                           String geofenceUnit, String terms, String weather, String timeToLocation,
                           String showCalculations, Integer overallBudget,
                           Integer maximumDailybudget, String country,
                           String userId, String description, String marketingGroup,
                           Integer normalPrice, Integer offerPrice, Boolean playPauseStatus, Integer budget, Float deliveryCost, String longitude, String latitude) {

//        String result = location.substring(1, location.length() - 1);
        Log.d("myList", "postdata: " + marketingGroup);

        String result22 = marketingGroup.substring(1, marketingGroup.length() - 1);
        Log.d("myList", "postdata: " + result22);
        List<String> myList = new ArrayList<String>(Arrays.asList(marketingGroup.split(",")));
        Log.d("myList", "postdata: " + myList);
//        Log.d("viru10", "postdata: " + "coupon_title"  + brand + pruduct + normalPrice + offerPrice + playPauseStatus);
        ApiInterface apiInterface = RetrofitClient.getClient().create(ApiInterface.class);

//        location.replaceAll("[]//", "");
        List<String> lastgroup = Collections.singletonList(marketingGroup);
//        Log.d("lastttone 1", "postdata: " + marketingGroup + "  " + location);
////        Log.d("lastttone 2", "postdata: "+lastgroup + "  "+lastlolcation);
////        String list = Arrays.toString(lastlolcation.toArray()).replace("[", "").replace("]", "");
////        Log.d("lastttone 3", "postdata: "+list);

//        List<Object> lastlolcation2 = Collections.singletonList(location);
//        String result = location.substring(1, location.length() - 1);
//        List<Object> lastlolcation = Collections.singletonList(result);
//        Log.d("lastttone ", "postdata: " + result);
//        Log.d("lastttone ", "postdata: " + lastlolcation);
//        Log.d("lastttone ", "postdata: " + lastlolcation2);
        RequestBody couponTitle1 = RequestBody.create(MediaType.parse("multipart/form-data"), couponTitle);
        RequestBody brand1 = RequestBody.create(MediaType.parse("multipart/form-data"), brand);
        RequestBody shop1 = RequestBody.create(MediaType.parse("multipart/form-data"), shop);
        RequestBody product1 = RequestBody.create(MediaType.parse("multipart/form-data"), product);
        RequestBody service1 = RequestBody.create(MediaType.parse("multipart/form-data"), service);
        RequestBody dealType1 = RequestBody.create(MediaType.parse("multipart/form-data"), dealType);
//        RequestBody offerText1 = RequestBody.create(MediaType.parse("multipart/form-data"), offerText);
//        RequestBody percentageDiscount1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(percentageDiscount));

        RequestBody currency1 = RequestBody.create(MediaType.parse("multipart/form-data"), currency);
//        RequestBody priceSaving1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(priceSaving));
//        RequestBody percentageSaving1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(percentageSaving));
//        RequestBody longProd1 = RequestBody.create(MediaType.parse("multipart/form-data"), longProd);
//        RequestBody serText1 = RequestBody.create(MediaType.parse("multipart/form-data"), serText);
        RequestBody launchDate1 = RequestBody.create(MediaType.parse("multipart/form-data"), launchDate);
        RequestBody launchTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), launchTime);
        RequestBody expiryDate1 = RequestBody.create(MediaType.parse("multipart/form-data"), expiryDate);

        RequestBody expiryTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), expiryTime);
        RequestBody shared1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(shared));
        RequestBody singleUse1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(singleUse));
        RequestBody maximumRedemptions1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(maximumRedemptions));
        RequestBody address11 = RequestBody.create(MediaType.parse("multipart/form-data"), address1);
        RequestBody address21 = RequestBody.create(MediaType.parse("multipart/form-data"), address2);

        RequestBody town1 = RequestBody.create(MediaType.parse("multipart/form-data"), town);
        RequestBody city1 = RequestBody.create(MediaType.parse("multipart/form-data"), city);
        RequestBody postcode1 = RequestBody.create(MediaType.parse("multipart/form-data"), postcode);
        RequestBody openingTimes1 = RequestBody.create(MediaType.parse("multipart/form-data"), openingTimes);
//        RequestBody message1 = RequestBody.create(MediaType.parse("multipart/form-data"), message);
//        RequestBody market1 = RequestBody.create(MediaType.parse("multipart/form-data"), market);
//        RequestBody profile1 = RequestBody.create(MediaType.parse("multipart/form-data"), profile);
        RequestBody messageGroup1 = RequestBody.create(MediaType.parse("multipart/form-data"), messageGroup);
        RequestBody distance1 = RequestBody.create(MediaType.parse("multipart/form-data"), distance);

        RequestBody journeyType1 = RequestBody.create(MediaType.parse("multipart/form-data"), journeyType);
//        RequestBody journeyTime1 = RequestBody.create(MediaType.parse("multipart/form-data"), journeyTime);
        RequestBody ageMin1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(ageMin));
        RequestBody ageMax1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(ageMax));
        RequestBody gender1 = RequestBody.create(MediaType.parse("multipart/form-data"), gender);
        RequestBody overTemperature1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(overTemperature));
        RequestBody underTemperature1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(underTemperature));

        RequestBody projectBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(projectBudget));
//        RequestBody projectCurrency1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(projectCurrency));
//        RequestBody dailyBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(dailyBudget));
//        RequestBody playPauseStatus1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(playPauseStatus));
//        RequestBody mapPin1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(mapPin));
//        RequestBody journey1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(journey));
        RequestBody distanceUnits1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(distanceUnits));
        RequestBody distancenum1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(distancenum));

        RequestBody locationType1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(locationType));
//        RequestBody journeyTyep1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(journeyTyep));
        RequestBody geofenceUnit1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(geofenceUnit));
        RequestBody terms1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(terms));
        RequestBody weather1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(weather));
        RequestBody timeToLocation1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(timeToLocation));
//        RequestBody budget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(budget));

//        RequestBody deliveryCost1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deliveryCost));
//        RequestBody deal1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deal));
        RequestBody showCalculations1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(showCalculations));
        RequestBody overallBudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(overallBudget));
        RequestBody maximumDailybudget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(maximumDailybudget));
        RequestBody country1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(country));
        RequestBody userId1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(userId));
        RequestBody description1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(description));
        RequestBody lastgroup1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(myList));
//        RequestBody lastlolcation21 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(location));

        RequestBody normalPrice1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(normalPrice));
        RequestBody offerPrice1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(offerPrice));
        RequestBody playPauseStatus1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(playPauseStatus));
        RequestBody budget1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(budget));
        RequestBody deliveryCost1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(deliveryCost));
        RequestBody longitude1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(longitude));
        RequestBody latitude1 = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(latitude));
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String coupon_id1 = sh.getString("coupon_id", "");
        Log.d("part123", "EditData2: " + coupon_id1);
        RequestBody edit_coupon_id = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(coupon_id1));

        Log.d("part123", "EditData2: " + part + edit_coupon_id);
//        Log.d("part123", "EditData2: " + coupon_id1);

        Call<EditData> call = apiInterface.Editcoupan(couponTitle1, brand1, shop1, product1, service1, dealType1,
                currency1, launchDate1, launchTime1, expiryDate1,
                expiryTime1, shared1, singleUse1, maximumRedemptions1, address11, address21
                , town1, city1, postcode1, openingTimes1, distance1,
                journeyType1, ageMin1, ageMax1, gender1, overTemperature1, underTemperature1,
                projectBudget1, distanceUnits1, distancenum1,
                locationType1, geofenceUnit1, terms1, weather1, timeToLocation1
                , showCalculations1, overallBudget1, maximumDailybudget1, country1, userId1, description1, normalPrice1, offerPrice1, playPauseStatus1, budget1, deliveryCost1, longitude1, latitude1, edit_coupon_id);

        call.enqueue(new Callback<EditData>() {


            @Override
            public void onResponse(@NonNull Call<EditData> call, @NonNull Response<EditData> response) {

                Log.d("devi1A", "onResponse: " + response.raw());

//                Toast.makeText(Addcoupon_activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();
//                Toast.makeText(Addcoupon_activity.this, "" + response.body(), Toast.LENGTH_SHORT).show();
//                Toast.makeText(Addcoupon_activity.this, "" + response.message(), Toast.LENGTH_SHORT).show();

                Log.d("respomse_data", "onResponse: " + response.raw());
                Log.d("respomse_data", "onResponse: " + response.body());
                Log.d("respomse_data", "onResponse: " + response.message());

                if (response.code() == 200) {

                    Toast.makeText(Addcoupon_activity.this, "YOUR COUPON IS SUCCESSFULLY EDITED", Toast.LENGTH_SHORT).show();
                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();

                    if (response.body().getData() != null) {

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                binding.progressbarList.setVisibility(View.INVISIBLE);

                                Intent get_main = new Intent(Addcoupon_activity.this, MainActivity.class);
                                get_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(get_main);
                            }
                        }, 2000);

                    } else {
                        Log.d("devi1A", "onResponse: Your Data is null");
                        Toast.makeText(Addcoupon_activity.this, "Your Data is null", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Log.d("devi1A", "onResponse: 1 else");
//                    Toast.makeText(Addcoupon_activity.this, " 1 else" + response.raw(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<EditData> call, @NonNull Throwable t) {
                Toast.makeText(Addcoupon_activity.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
                Log.d("devi1A", "onFailure: " + t);

            }
        });
    }

//    private void EditData2(String couponTitle, String brand, String shop, String product, String service, String dealType,
//                           String offerText, Integer percentageDiscount, Integer normalPrice, Integer offerPrice,
//                           Boolean displayPriceSaving, Boolean displayPercentSaving, String longProd, String serText,
//                           String launchDate, String launchTime, String expiryDate, String expiryTime, Boolean shared,
//                           Boolean singleUse, Integer maximumRedemptions, String address1, String address2, String town,
//                           String city, String postcode, String openingTimes, String message, String market, String profile,
//                           String marketingGroup, String messageGroup, String distance, String journeyType, String journeyTime,
//                           Integer ageMin, Integer ageMax, String gender, Integer overTemperature, Integer underTemperature,
//                           String mapPin, String projectCurrency, Integer dailyBudget, String journey, Integer projectBudget,
//                           Boolean playPauseStatus, String distanceUnits, Integer distancenum, String locationType
//            , String geofenceUnit, String terms, String timeToLocation, Float budget,
//                           String showCalculations, Double deliveryCost, Integer deal, Integer overallBudget, String country,
//                           Integer maximumDailybudget, String userId, String currency, String couponImage) {
//
//        ApiInterface apiInterface = RetrofitClient.getClient().create(ApiInterface.class);
//    }

    private void selectImage() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(i, "Select Picture"), GALLERY_REQ_CODE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == GALLERY_REQ_CODE) {
                Uri selectedImageUri = data.getData();
                SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = pref.edit();
                myEdit.putString("selectedImageUri1", String.valueOf(selectedImageUri));
                myEdit.apply();
                if (null != selectedImageUri) {
                    bitmap = BitmapFactory.decodeFile(String.valueOf(selectedImageUri));
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                        bitmap = BitmapFactory.decodeStream(inputStream);
                        binding.imgFromUser.setImageBitmap(bitmap);
                        String btos = BitMapToString(bitmap);
                        preferences.save(Addcoupon_activity.this, preferences.KEY_Bitmap, String.valueOf(btos));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    File file = new File(getRealPathFromURI(selectedImageUri, getApplicationContext()));
                    RequestBody requestBody = RequestBody.create(MediaType.parse("image/"), file);
                    part = MultipartBody.Part.createFormData("couponImage", file.getName(), requestBody);
                    Log.d("final files", "onActivityResult: " + file);
                    Log.d("filepath", "onActivityResult: " + file.getName());
                    Log.d("final files on ", "onActivityResult: " + part);
                    preferences.save(Addcoupon_activity.this, preferences.KEY_Part, String.valueOf(part));
                    preferences.save(Addcoupon_activity.this, preferences.KEY_File, String.valueOf(file));

                }
            }
        }
    }

    @Nullable
    public final String getRealPathFromURI(@NotNull Uri uri, @NotNull Context context) {
        Intrinsics.checkNotNullParameter(uri, "uri");
        Intrinsics.checkNotNullParameter(context, "context");
        Cursor returnCursor = context.getContentResolver().query(uri, (String[]) null, (String) null, (String[]) null, (String) null);
        Intrinsics.checkNotNull(returnCursor);
        int nameIndex = returnCursor.getColumnIndex("_display_name");
        int sizeIndex = returnCursor.getColumnIndex("_size");
        returnCursor.moveToFirst();
        String name = returnCursor.getString(nameIndex);
        String size = String.valueOf(returnCursor.getLong(sizeIndex));
        File file = new File(context.getFilesDir(), name);

        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1048576;
            int bytesAvailable = inputStream != null ? inputStream.available() : 0;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
            byte[] buffers = new byte[bufferSize];

            while (true) {
                Integer var16 = inputStream != null ? inputStream.read(buffers) : null;
                boolean var18 = false;
                if (var16 != null) {
                    read = var16;
                }

                if (var16 != null) {
                    if (var16 == -1) {
                        Log.e("File Size", "Size " + file.length());
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        outputStream.close();
                        Log.e("File Path", "Path " + file.getPath());
                        break;
                    }
                }

                outputStream.write(buffers, 0, read);
            }
        } catch (Exception var19) {
            String var10001 = var19.getMessage();
            Intrinsics.checkNotNull(var10001);
            Log.e("Exception", var10001);
        }

        return file.getPath();
    }

    public void id_vise_coupon_data(String ids) {
        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();
        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        clientBuilder.addInterceptor(loggingInterceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://54.90.77.44:8000/coupon/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);

        try {

            String id = ids;

            JSONObject paramObject = new JSONObject();
            paramObject.put("id", id);
            Log.d("devi123", "onCreate: " + paramObject);
            Call<IdwiseCoupon> userCall = apiInterface.get_id_wise_data(String.valueOf(paramObject));
            userCall.enqueue(new Callback<IdwiseCoupon>() {

                @Override
                public void onResponse(Call<IdwiseCoupon> call, Response<IdwiseCoupon> response) {
                    Log.d("viru_qrcode", "onResponse: " + response.raw());
//                    Toast.makeText(Addcoupon_activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();

                    if (response.code() == 200) {

//                      Toast.makeText(Addcoupon_activity.this, "" + response.raw(), Toast.LENGTH_SHORT).show();

                        //Add coupon Data
                        String title = response.body().getCouponData().getCouponTitle();
                        String Copon_image = (String) response.body().getCouponData().getCouponImage();
                        String brand = response.body().getCouponData().getBrand();
                        String Product = response.body().getCouponData().getProduct();
                        String budget = String.valueOf(response.body().getCouponData().getBudget());
                        String overall_budget = String.valueOf(response.body().getCouponData().getOverallBudget());
                        String delivery_cost = String.valueOf(response.body().getCouponData().getDeliveryCost());

                        String userid = response.body().getCouponData().getUserId();
                        String edt_entermaximumbudget = String.valueOf(response.body().getCouponData().getMaximumDailybudget());

                        myEdit.putString("title", title);
                        myEdit.putString("Copon_image", Copon_image);
                        myEdit.putString("brand", brand);
                        myEdit.putString("Product", Product);
                        myEdit.putString("budget", budget);
                        myEdit.putString("overall_budget", overall_budget);
                        myEdit.putString("delivery_cost", delivery_cost);
                        myEdit.putString("userid", userid);
                        myEdit.putString("edt_entermaximumbudget", edt_entermaximumbudget);

                        //Deal Acivity data
                        String deal_type = response.body().getCouponData().getDealType();
                        String currency = response.body().getCouponData().getCurrency();
                        String regular_price = String.valueOf(response.body().getCouponData().getNormalPrice());
                        String offer_price = String.valueOf(response.body().getCouponData().getOfferPrice());
                        String calculation = response.body().getCouponData().getShowCalculations();
                        String launchdate = response.body().getCouponData().getLaunchDate();
                        String lh_date = launchdate.substring(0, 10);
                        String[] launch_date2 = lh_date.split("-");
                        String launch_date3 = launch_date2[0];
                        String launch_date4 = launch_date2[1];
                        String launch_date5 = launch_date2[2];

                        String last_launch_date = launch_date5 + "/" + launch_date4 + "/" + launch_date3 + " ";

                        String[] launch_time = launchdate.split("T");
                        String final_launch_time = launch_time[1];
                        String launch_time_1 = final_launch_time.substring(0, 8);
                        String exprirydate = response.body().getCouponData().getExpiryDate();
                        String ex_date = exprirydate.substring(0, 10);

                        String[] expiry_date2 = lh_date.split("-");
                        String expiry_date3 = expiry_date2[0];
                        String expiry_date4 = expiry_date2[1];
                        String expiry_date5 = expiry_date2[2];

                        String last_expiry_date = expiry_date5 + "/" + expiry_date4 + "/" + expiry_date3 + " ";

                        String[] expiry_time = exprirydate.split("T");
                        String final_expiry_time = expiry_time[1];
                        String expiry_time_1 = final_expiry_time.substring(0, 8);
                        String description = response.body().getCouponData().getDescription();
                        Boolean can_share = response.body().getCouponData().getShared();
                        Boolean getSingleUse = response.body().getCouponData().getSingleUse();
                        String maximum_redumption = String.valueOf(response.body().getCouponData().getMaximumRedemptions());

                        //target activity data

                        String market_group = String.valueOf(response.body().getCouponData().getMarketingGroup());
                        String location_mthod = response.body().getCouponData().getLocationType();
                        String journey_type = response.body().getCouponData().getJourneyType();
                        String min_age = String.valueOf(response.body().getCouponData().getAgeMin());
                        String max_age = String.valueOf(response.body().getCouponData().getAgeMax());
                        String gender = response.body().getCouponData().getGender();
                        String weather = response.body().getCouponData().getWeather();
                        String distanceUnits = response.body().getCouponData().getDistanceUnits();
                        String distancenum = response.body().getCouponData().getDistance();
                        String journeyTime = response.body().getCouponData().getJourneyTime();
                        String min_temp = String.valueOf(response.body().getCouponData().getUnderTemperature());
                        String max_temp = String.valueOf(response.body().getCouponData().getOverTemperature());

                        //location activity

                        String adress1 = response.body().getCouponData().getAddress1();
                        String adress2 = response.body().getCouponData().getAddress2();
                        String town_city = response.body().getCouponData().getCity();
                        String country = response.body().getCouponData().getCountry();
                        String opening_time = response.body().getCouponData().getOpeningTimes();
                        String latitude = response.body().getCouponData().getLatitude();
                        String lat = latitude.substring(0, 6);
                        String longitude = response.body().getCouponData().getLongitude();
                        String lang = longitude.substring(0, 6);
                        String location_image = (String) response.body().getCouponData().getAddressImage();
                        String postcode = response.body().getCouponData().getPostcode();
                        String opening_times = response.body().getCouponData().getOpeningTimes();

                        //terms activity
                        String terms = response.body().getCouponData().getTerms();
                        String coupon_id = response.body().getCouponData().getId();


                        Log.d("id_wise_data132", "onResponse: " + title + " " + brand + " " + Product
                                + " " + budget + " " + currency + " " + offer_price + " " + calculation + " " +
                                regular_price + " " + lh_date + " " + launch_time_1 + " " + ex_date + " " + expiry_time_1 + " " +
                                /* exprirytime + */" " + can_share + " " + getSingleUse + " " + maximum_redumption + " " +
                                location_mthod + " " + journey_type + " " + min_age + max_age + " " + gender + " " +
                                weather + " " + distanceUnits + " " + distancenum + " " + journeyTime + " " +
                                min_temp + " " + max_temp + " " + adress1 + " " + adress2 + " " + town_city + " " + country + " "
                                + opening_time + " " + latitude + " " + longitude + " " + location_image + " " + postcode + " " + opening_times);

                        URL url = null;
                        try {
                            url = new URL(Copon_image);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                        Picasso.get().load(String.valueOf(url)).into(binding.imgFromUser);

                        binding.edtEnterTitle.setText(title);
                        binding.edtEnterProduct.setText(Product);
                        binding.edtEnterShop.setText(brand);
                        binding.txtBudgetPrice.setText(overall_budget);
                        binding.txtDeliveryCharge.setText(delivery_cost);

//                        Log.d("deal_data", "onResponse: " + calculation + launchdate + launctime + exprirydate + exprirytime + can_share + getSingleUse + maximum_redumption);


                        myEdit.putString("currency", currency);
                        myEdit.putString("dealtype", deal_type);
                        myEdit.putString("regular_price", regular_price);
                        myEdit.putString("offer_price", offer_price);
                        myEdit.putString("calculation", calculation);
                        myEdit.putString("launchdate", last_launch_date);
                        myEdit.putString("final_launch_time", launch_time_1);
                        myEdit.putString("exprirydate", last_expiry_date);
                        myEdit.putString("final_expiry_time", expiry_time_1);

                        myEdit.putString("description", description);
                        myEdit.putString("maximum_redumption", maximum_redumption);

                        boolean share1 = response.body().getCouponData().getShared();
                        Log.d("share1", "onCreate: " + share1);
                        if (share1) {
                            myEdit.putString("share", "Yes");
                            myEdit.apply();
                        } else {
                            myEdit.putString("share", "No");
                            myEdit.apply();
                        }

                        boolean use1 = response.body().getCouponData().getSingleUse();

                        Log.d("use1", "onCreate: " + use1);
                        if (use1) {
                            myEdit.putString("use", "Yes");
                            myEdit.apply();
                        } else {
                            myEdit.putString("use", "No");
                            myEdit.apply();
                        }
//                        //location activity
                        myEdit.putString("address1", adress1);
                        myEdit.putString("address2", adress2);
                        myEdit.putString("town_city", town_city);

                        if (country.equals("UK")) {
                            myEdit.putString("country", "United Kingdom");
                        } else {
                            myEdit.putString("country", country);
                        }

                        myEdit.putString("opening_time", opening_time);
                        myEdit.putString("latitude", lat);
                        myEdit.putString("longitude", lang);
                        myEdit.putString("location_image", location_image);
                        myEdit.putString("postcode", postcode);
                        myEdit.putString("opening_times", opening_times);

                        //terms activity
                        myEdit.putString("terms", terms);
                        myEdit.putString("coupon_id", coupon_id);

                        //target activity

                        myEdit.putString("method", location_mthod);
                        myEdit.putString("miiin", min_age);
                        myEdit.putString("maxxxx", max_age);
                        myEdit.putString("gender", gender);
                        myEdit.putString("weather", weather);
                        myEdit.putString("tempmin", min_temp);
                        myEdit.putString("tempmax", max_temp);
                        myEdit.putString("market_group", market_group);

                        myEdit.putString("units", distanceUnits);
                        myEdit.putString("distancenum", distancenum);
                        myEdit.putString("journeyTime", journeyTime);
                        myEdit.putString("journey", journey_type);

                        myEdit.apply();


                    } else {
                        Toast.makeText(Addcoupon_activity.this, "An Error Occurred", Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onFailure(Call<IdwiseCoupon> call, Throwable t) {
                    Log.d("error_failure", "onFailure: " + "an error occurred" + " " + t);
                    Toast.makeText(Addcoupon_activity.this, "" + t, Toast.LENGTH_SHORT).show();
                }
            });
        } catch (
                JSONException e) {
            e.printStackTrace();
        }
    }

    public void add_payment() {
        new AlertDialog.Builder(this)
                .setTitle("Payment Method")
                .setMessage("Do You Want To Pay Now?")
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Addcoupon_activity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                })
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent intent = new Intent(Addcoupon_activity.this, Payment_method.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("flag", "payment");
                        startActivity(intent);
                    }
                }).create().show();
    }

    public static Bitmap convertStringToBitmap(String string) {
        byte[] byteArray1;
        byteArray1 = Base64.decode(string, Base64.DEFAULT);
        Bitmap bmp = BitmapFactory.decodeByteArray(byteArray1, 0,
                byteArray1.length);/* w  w  w.ja va 2 s  .  c om*/
        return bmp;
    }

    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    public Bitmap StringToBitMap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0,
                    encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }

    public MultipartBody.Part createpart(String filesles) {

        MultipartBody.Part newparts;
        File file223 = new File(filesles);
        Log.d("final files 3 f ", "onCreate: " + file223);
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/"), file223);
        newparts = MultipartBody.Part.createFormData("couponImage", file223.getName(), requestBody);
        Log.d("final files 5 pp ", "onCreate: " + newparts);
        return newparts;
    }

    public MultipartBody.Part editcreatepart(String filesles) {

        MultipartBody.Part newparts;
        File file223 = new File(filesles);
        Log.d("final files 3 f ", "onCreate: " + file223);
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/"), file223);
        newparts = MultipartBody.Part.createFormData("couponImage", file223.getName(), requestBody);
        Log.d("final files 5 pp ", "onCreate: " + newparts);
        return newparts;
    }

    public MultipartBody.Part createpart2(String filesles) {

        MultipartBody.Part newparts;
        File file223 = new File(filesles);
        Log.d("final files 3 f ", "onCreate: " + file223);
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/"), file223);
        newparts = MultipartBody.Part.createFormData("addressImage", file223.getName(), requestBody);
        Log.d("final files 5 pp ", "onCreate: " + newparts);
        return newparts;
    }


    @Override
    public void onBackPressed() {

        Intent get_main = new Intent(Addcoupon_activity.this, MainActivity.class);
        get_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(get_main);
    }
    public static File bitmapToFile(Context context,Bitmap bitmap, String fileNameToSave) { // File name like "image.png"
        //create a file to write bitmap data
        File file = null;
        try {
            file = new File(Environment.getExternalStorageDirectory() + File.separator + fileNameToSave);
            file.createNewFile();

//Convert bitmap to byte array
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 0 , bos); // YOU can also save it in JPEG
            byte[] bitmapdata = bos.toByteArray();

//write the bytes in file
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
            return file;
        }catch (Exception e){
            e.printStackTrace();
            return file; // it will return null
        }
    }
}
