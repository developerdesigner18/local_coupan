

package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.example.local_coupan.databinding.ActivityCouponVerifyBinding;

public class coupon_verify_activity extends AppCompatActivity {
    ActivityCouponVerifyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCouponVerifyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.imgVerifyBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String title = sh.getString("coupon_title", "");
        String message = sh.getString("message", "");
        int percentageDiscount = sh.getInt("percentageDiscount", 0);

        String discount = String.valueOf(percentageDiscount);

        binding.titleCouponName.setText(title);
        binding.discount.setText(discount);
        binding.message.setText(message);
        binding.couponDesc.setText(title);

        binding.btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_scan = new Intent(coupon_verify_activity.this, Scanner_activity.class);
                get_scan.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_scan);
            }
        });

    }
}