package com.example.local_coupan.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import com.google.android.material.card.MaterialCardView;

import com.google.android.material.card.MaterialCardView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.local_coupan.R;
import com.example.local_coupan.model.get_coupon_data.CouponDatum2;
import com.example.local_coupan.model.get_coupon_data.GetCouponData;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class recycler_couponadapter extends RecyclerView.Adapter<recycler_couponadapter.viewholder> implements Filterable {

    OnItemClickListener mlisner;
    List<CouponDatum2> list;
    List<CouponDatum2> search_list;

    public void setOnItemClicklistner(OnItemClickListener listener) {
        mlisner = listener;
    }

    public recycler_couponadapter(List<CouponDatum2> list) {
        this.list = list;
        search_list = new ArrayList<>(list);
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence keyword) {

            List<CouponDatum2> filteredata = new ArrayList<>();

            if (keyword.toString().isEmpty()) {
                filteredata.addAll(search_list);
            } else {
                //String filterPattern = keyword.toString().toLowerCase().trim();

                for (CouponDatum2 obj : search_list) {
                    if (obj.getCouponTitle().toLowerCase().contains(keyword.toString().toLowerCase())) {
                        Log.d("TAG123", "performFiltering: devi1 if");
                        filteredata.add(obj);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredata;
            return results;
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            list.clear();

            //     list.addAll((List) results.values);
            //    Log.d("TAG", "publishResults: devi1 1");

            //list.addAll((ArrayList<Datum>) results.values);
//            Log.d("TAG", "publishResults: devi1 2");

            list.addAll((Collection<CouponDatum2>) results.values);
            Log.d("TAG", "publishResults: devi1 3");

            notifyDataSetChanged();
        }
    };

    public interface OnItemClickListener {

        void onbudgetclick(int position);

        void ondeliveries(int position);

        void scanned(int position);

        void onrunclick(int posision);

        void onpreviewclick(int posision);

        void oneditlick(int posision);

        void onshareclick(int position);
    }


    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_coupon_adapter, parent, false);

        viewholder myviewholder = new viewholder(view, (OnItemClickListener) mlisner);
        return myviewholder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {

        holder.txt_coupon_title.setText(list.get(position).getCouponTitle());

        Boolean status = list.get(position).getPlayPauseStatus();

        Log.d("PlayPauseStatus123", "onBindViewHolder: " + status);
        Log.d("PlayPauseStatus123", "onBindViewHolder: " + list.get(position).getId());

        if (list.get(position).getPlayPauseStatus().equals(true)) {

            holder.txt_coupon_live.setText("Live");
            holder.txt_play.setText("Pause");
            holder.btn_run.setCardBackgroundColor(Color.parseColor("#FF9327"));

        } else if (list.get(position).getPlayPauseStatus().equals(false)) {

            holder.txt_coupon_live.setText("Paused");
            holder.txt_play.setText("Play");
            holder.btn_run.setCardBackgroundColor(Color.GREEN);

        }

        if (list.get(position).getStatistics().get(0).getRemainingBudget() == null) {
            holder.txt_price.setText("0");
        }else{
            holder.txt_price.setText(list.get(position).getStatistics().get(0).getRemainingBudget().toString());
        }
        if (list.get(position).getStatistics().get(0).getDeliveries() == null) {
            holder.txt_deliveries_price.setText("0");
        }else{
            holder.txt_deliveries_price.setText(list.get(position).getStatistics().get(0).getDeliveries().toString());
        }
        if (list.get(position).getStatistics().get(0).getScannedRedemptions() == null) {
            holder.txt_scanned_number.setText("0");
        }else{
            holder.txt_scanned_number.setText(list.get(position).getStatistics().get(0).getScannedRedemptions().toString());
        }
        boolean share = list.get(position).getShared();
        if (share){
            holder.btn_share.setVisibility(View.VISIBLE);
        }else{
            holder.btn_share.setVisibility(View.GONE);
        }
//        holder.txt_deliveries.setText(list.get(position).getTxt_deliveries());
//        holder.txt_budget.setText(list.get(position).get());
        //        holder.txt_scanned_redemption.setText(list.get(position).getTxt_scanned_redemption());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    Context context;

    public static class viewholder extends RecyclerView.ViewHolder {

        TextView txt_coupon_title, txt_coupon_live, txt_budget, txt_price, txt_deliveries,
                txt_deliveries_price, txt_scanned_redemption, txt_scanned_number, txt_play;
        CardView btn_run, btn_preview, btn_edit, btn_share;
        LinearLayout llout1, llout2, llout3;

        @SuppressLint("SetTextI18n")
        public viewholder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);

            txt_coupon_title = itemView.findViewById(R.id.txt_coupon_title);
            txt_coupon_live = itemView.findViewById(R.id.txt_coupon_live);
            txt_budget = itemView.findViewById(R.id.txt_budget);
            txt_price = itemView.findViewById(R.id.txt_price);
            txt_deliveries = itemView.findViewById(R.id.txt_deliveries);
            txt_deliveries_price = itemView.findViewById(R.id.txt_deliveries_price);
            txt_scanned_redemption = itemView.findViewById(R.id.txt_scanned_redemption);
            txt_scanned_number = itemView.findViewById(R.id.txt_scanned_number);
            txt_play = itemView.findViewById(R.id.txt_play);

            btn_run = itemView.findViewById(R.id.btn_run);
            btn_preview = itemView.findViewById(R.id.btn_preview);
            btn_edit = itemView.findViewById(R.id.btn_edit);
            btn_share = itemView.findViewById(R.id.btn_main_share);

            llout1 = itemView.findViewById(R.id.llout1);
            llout2 = itemView.findViewById(R.id.llout2);
            llout3 = itemView.findViewById(R.id.llout3);

            btn_run.setOnClickListener(v -> {

                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.onrunclick(position1);

                        Log.d("viru1", "viewholder: " + txt_coupon_live.getText().toString());

                        if (txt_coupon_live.getText().toString().equals("Live")) {

                            Log.d("viru2", "viewholder: 2");
                            txt_coupon_live.setText("Pause");
                            txt_play.setText("Play");
                            btn_run.setCardBackgroundColor(Color.GREEN);

                        } else if (txt_coupon_live.getText().toString().equals("Pause")) {
                            Log.d("viru2", "viewholder: 3");
                            txt_coupon_live.setText("Live");
                            txt_play.setText("Pause");
                            btn_run.setCardBackgroundColor(Color.parseColor("#FF9327"));

                        }
                    }
                }
            });

            btn_share.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.onshareclick(position1);
                    }
                }
            });

            btn_preview.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.onpreviewclick(position1);
                    }
                }
            });


            btn_edit.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.oneditlick(position1);
                    }
                }
            });

            llout1.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.onbudgetclick(position1);
                    }
                }
            });

            llout2.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.ondeliveries(position1);
                    }
                }
            });

            llout3.setOnClickListener(v -> {
                if (listener != null) {
                    int position1 = getAdapterPosition();
                    if (position1 != RecyclerView.NO_POSITION) {
                        listener.scanned(position1);
                    }
                }
            });
        }
    }
}