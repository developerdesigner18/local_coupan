
package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.example.local_coupan.databinding.ActivityOfferTermsBinding;
import com.squareup.picasso.Picasso;

import java.net.MalformedURLException;
import java.net.URL;

public class Offer_terms_activity extends AppCompatActivity {
    ActivityOfferTermsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOfferTermsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

//        String image = getIntent().getStringExtra("image");
        String terms = sh.getString("terms", "");
        String id = sh.getString("id", "");
        String CouponImage = sh.getString("CouponImage", "");

        binding.couponId.setText(id);
        binding.txtTermss123.setText(terms);

        URL url = null;
        try {
            url = new URL(CouponImage);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Picasso.get().load(String.valueOf(url)).into(binding.imageView3);

        binding.imgOfferTermsBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
//                Offer_terms_activity.super.onBackPressed();
            }
        });

        binding.yucallTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_yucall = new Intent(Offer_terms_activity.this, Yucall_terms_activity.class);
                get_yucall.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_yucall);
            }
        });
    }}