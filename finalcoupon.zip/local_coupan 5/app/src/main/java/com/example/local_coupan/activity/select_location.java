
package com.example.local_coupan.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.local_coupan.R;
import com.example.local_coupan.databinding.ActivitySelectLocationBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Picasso;

import java.net.MalformedURLException;
import java.net.URL;

public class select_location extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mMap;
    private ActivitySelectLocationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectLocationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
        binding.imgLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                binding.imgLocation.setImageResource(R.drawable.location1);

                binding.imgTime.setImageResource(R.drawable.sand_clock);
                binding.imgCoin.setImageResource(R.drawable.coin);

            }
        });

        binding.imgCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.imgTime.setImageResource(R.drawable.sand_clock);
                binding.imgCoin.setImageResource(R.drawable.coin1);
                binding.imgLocation.setImageResource(R.drawable.location);
            }
        });

        binding.imgTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.imgTime.setImageResource(R.drawable.sandclock1);
                binding.imgCoin.setImageResource(R.drawable.coin);
                binding.imgLocation.setImageResource(R.drawable.location);
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        mMap = googleMap;

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String latitude = sh.getString("latitude", "");
        String longitude = sh.getString("longitude", "");

        double lat = Double.parseDouble(latitude);
        double lang = Double.parseDouble(longitude);

        LatLng map_pin = new LatLng(lat, lang);

//        LatLng sydney = new LatLng(21.19756486206005, 72.79386539801251);
        LatLng sydney = new LatLng(lat, lang);
        mMap.addMarker(new MarkerOptions().position(sydney));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lang), 10));
//        mMap.setInfoWindowAdapter(new custom_info_window(select_location.this));
        mMap.setInfoWindowAdapter(new custom_info_window(select_location.this));

    }

    public class custom_info_window implements GoogleMap.InfoWindowAdapter {

        private final View mWindow;

        @SuppressLint("InflateParams")
        public custom_info_window(Context mcontext) {
            mWindow = LayoutInflater.from(mcontext).inflate(R.layout.custom_map_window, null);
        }

        @SuppressLint("SetTextI18n")
        private void rendowWindowText(Marker marker, View view) {

            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

            String city_data = sh.getString("city", "");
            String address1_data = sh.getString("address1", "");
            String address2_data = sh.getString("address2", "");
            String title_data = sh.getString("title", "");
            String brand_data = sh.getString("brand", "");
            String country_data = sh.getString("country", "");
            String address_image = sh.getString("address_image", "");
            String CouponImage = sh.getString("CouponImage", "");

            String add_image = address_image;
            Log.d("address_image", "rendowWindowText: " + address_image);
            Log.d("CouponImage", "rendowWindowText: " + CouponImage);

            TextView tvtitle = view.findViewById(R.id.title_window);
            TextView tvbrand = view.findViewById(R.id.brand_window);
            TextView address1 = view.findViewById(R.id.address1_window);
            TextView address2 = view.findViewById(R.id.address2_window);
            TextView city = view.findViewById(R.id.address3_window);

            Log.d("location_data", "rendowWindowText: " + title_data + " " + brand_data);
            ImageView img_icon = view.findViewById(R.id.img_coupon_window);
            ImageView location = view.findViewById(R.id.img_location_window);

            tvtitle.setText(title_data);
            tvbrand.setText(brand_data);
            address1.setText(address1_data);
            address2.setText(address2_data);
            city.setText(city_data);

            if (add_image.equalsIgnoreCase("http://54.90.77.44:8000/public/images/undefined")) {
                location.setImageResource(R.drawable.location_image);
            }else if(add_image.isEmpty()){
                location.setImageResource(R.drawable.location_image);
            } else {
                URL url2 = null;
                try {
                    url2 = new URL(add_image);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                Picasso.get().load(String.valueOf(url2)).into(location);
            }

            if (CouponImage.equalsIgnoreCase("http://54.90.77.44:8000/public/images/undefined")) {
                img_icon.setImageResource(R.drawable.logo);
            }else if(CouponImage.isEmpty()){
                img_icon.setImageResource(R.drawable.logo);
            } else {
                URL url1 = null;
                try {
                    url1 = new URL(CouponImage);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                Picasso.get().load(String.valueOf(url1)).into(img_icon);
            }
        }

        @Nullable
        @Override
        public View getInfoContents(@NonNull Marker marker) {
            rendowWindowText(marker, mWindow);
            return mWindow;
        }

        @Nullable
        @Override
        public View getInfoWindow(@NonNull Marker marker) {
            rendowWindowText(marker, mWindow);
            return mWindow;
        }
    }
}