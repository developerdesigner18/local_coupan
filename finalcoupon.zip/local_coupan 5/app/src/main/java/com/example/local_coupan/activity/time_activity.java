
package com.example.local_coupan.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.local_coupan.databinding.ActivityTimeBinding;

public class time_activity extends AppCompatActivity {
    ActivityTimeBinding binding;
    int mYear, mMonth, mDay, mHour, mMinute;
    String time_stamp = "null";
    String time;
    String flag = "null";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTimeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        if (getIntent().getStringExtra("navigate").equals("expiry")) {

            flag = "expiry_time";
            SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            String expiry_launch_time = sh.getString("expiry_launch_time", "");
            Log.d("expiry_launch_month", "onCreate: " + expiry_launch_time);
            binding.edtTime.setText(expiry_launch_time);

            getSelectedTime();

            binding.imgBackCurrency.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(time_activity.this, Launch_date_activity.class);
                    intent.putExtra("navigate", "expiry");
                    startActivity(intent);
//                    onBackPressed();
                }
            });
        } else if (getIntent().getStringExtra("navigate").equals("launch")) {

            flag = "launch_time";

            SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            String launch_time = sh.getString("launch_time", "");
            Log.d("launch_time", "onCreate: " + launch_time);
            binding.edtTime.setText(launch_time);

            getSelectedTime();

            binding.imgBackCurrency.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(time_activity.this, Launch_date_activity.class);
                    intent.putExtra("navigate", "launch");
                    startActivity(intent);
//                    onBackPressed();
                }
            });
        }
    }

    private void getSelectedTime() {
        binding.simpleTimePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {

                String hour = String.valueOf(hourOfDay);
                String minute1 = String.valueOf(minute);

                if (hourOfDay >= 0 && hourOfDay < 12) {

                    if (hourOfDay <= 9) {
                        hour = "0" + hourOfDay;
                    }
                    if (minute <= 9) {
                        minute1 = "0" + minute;
                    }
                    time = hour + ":" + minute1 + ":00" + " AM";


                } else {
                    if (hourOfDay == 12) {
                        if (hourOfDay <= 9) {
                            hour = "0" + hourOfDay;
                        }
                        if (minute <= 9) {
                            minute1 = "0" + minute;
                        }
                        time = hour + ":" + minute1 + ":00" + " PM";
                    } else {
                        if (hourOfDay <= 9) {
                            hour = "0" + hourOfDay;
                        }
                        if (minute <= 9) {
                            minute1 = "0" + minute;
                        }
                        time = hour + ":" + minute1 + ":00" + " PM";
                    }
                }

                Log.d("viru_time1", "tiemPicker: " + time);
                binding.edtTime.setText(time);
                SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = pref.edit();

                Log.d("flag123", "onTimeChanged: " + flag);

                if (flag.equals("expiry_time")) {
                    myEdit.putString("expiry_launch_time", time);
                    myEdit.apply();
                } else if (flag.equals("launch_time")) {
                    myEdit.putString("launch_time", time);
                    myEdit.apply();
                    Log.d("devi42", "onTimeChanged: " + pref.getString("launch_time", ""));
                }
                Log.d("devi4", "onTimeChanged: " + pref.getString("expiry_launch_time", ""));
            }
        });
    }
}