package com.example.local_coupan.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.local_coupan.databinding.ActivityCouponDealBinding;
import com.example.local_coupan.preferences2;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class
Coupon_deal_activity extends AppCompatActivity {
    ActivityCouponDealBinding binding;
    preferences2 preferences;
    String flag = "null";

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCouponDealBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getIntent().getStringExtra("type").equals("1")) {

            flag = "add";
            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();

            binding.edtRegularPriceValue.setText(pref.getString("Rprice", ""));
            binding.edtOfferPriceValue.setText(pref.getString("offerpricce", ""));
            binding.txtDescription.setText(pref.getString("Dessss", ""));
            binding.txtMaximumAmount.setText(pref.getString("maxi", ""));
            Log.d("dataaaa", "onCreate: " + pref.getString("maxi", ""));


            binding.edtOfferPriceValue.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                    if (!binding.edtRegularPriceValue.getText().toString().isEmpty()) {

                        if (binding.edtOfferPriceValue.length() == 0) {

                            Toast.makeText(Coupon_deal_activity.this, "Enter Value ", Toast.LENGTH_SHORT).show();

                        } else {

                            String regular_price = binding.edtRegularPriceValue.getText().toString().trim();
                            int final_regular = Integer.parseInt(regular_price);
                            String offer_price = binding.edtOfferPriceValue.getText().toString().trim();
                            int final_offer = Integer.parseInt(offer_price);

                            if (final_regular < final_offer) {
                                binding.edtOfferPriceValue.setError("Offer Value is more than Regular Value");
                            } else {

//                                Toast.makeText(Coupon_deal_activity.this, "Your Value is done", Toast.LENGTH_SHORT).show();

                            }
                        }

                    } else {

                        binding.edtRegularPriceValue.setError("Please Enter Value");
                        Toast.makeText(Coupon_deal_activity.this, "Enter Value in Regular Price", Toast.LENGTH_SHORT).show();

                    }
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });


            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale.getDefault());
            SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            String currentDateandTime = sdf.format(new Date());
            String currentDateandTime2 = sdf2.format(new Date());
            String currentDateandTime3 = sdf3.format(new Date());

            binding.edtDateTimePicker.setText(currentDateandTime);

            if (sh.getString("flag_val", "").equals("from_launch")) {

                String launch_year = sh.getString("launch_year", "");
                String launch_month = sh.getString("launch_month", "");
                String launch_month_num = sh.getString("launch_month_num", "");
                String launch_date = sh.getString("launch_date", "");
                String launch_time = sh.getString("launch_time", "");
                Log.d("launch_time12", "onCreate: " + launch_year);
                binding.edtDateTimePicker.setText(launch_date + "/" + launch_month_num + "/" + launch_year + " " + launch_time);

            } else {

                sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale.getDefault());
                sdf2 = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                sdf3 = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                currentDateandTime = sdf.format(new Date());
                currentDateandTime2 = sdf2.format(new Date());
                currentDateandTime3 = sdf3.format(new Date());

                binding.edtDateTimePicker.setText(currentDateandTime);

            }
            myEdit.putString("currentDateandTime1", currentDateandTime);
            String deal_type = sh.getString("dealtype", "");
            String Currency_type = sh.getString("usd", "");
            String show_calculation = sh.getString("calculation", "");
            String show_share = sh.getString("share", "");
            String show_use = sh.getString("use", "");
            binding.txtDealtypeDiscount.setText(deal_type);

            binding.txtCurrencyType.setText(Currency_type);

            binding.txtCalculationPercentage.setText(show_calculation);

            binding.txtShare.setText(show_share);

            binding.txtSingleYes.setText(show_use);

            Log.d("navigate", "onCreate: " + getIntent().getStringExtra("navigate"));

            binding.lloutDealtype.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, dealtype_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "1");
                    startActivity(get_dealtype);
                }
            });

            binding.lloutCurrency.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, Show_Currency_activity.class);
                    myEdit.apply();
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "1");
                    startActivity(get_dealtype);

                }
            });

            binding.lloutCalculation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, show_calculation_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "1");
                    startActivity(get_dealtype);
                }
            });


            binding.lloutShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_share = new Intent(Coupon_deal_activity.this, share_and_use_activity.class);
                    get_share.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_share.putExtra("navigate", "share");
                    get_share.putExtra("type", "1");
                    startActivity(get_share);
                }
            });


            binding.lloutUses.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_share = new Intent(Coupon_deal_activity.this, share_and_use_activity.class);
                    get_share.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_share.putExtra("type", "1");
                    get_share.putExtra("navigate", "use");
                    startActivity(get_share);
                }
            });

            binding.imgCouponDealBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Coupon_deal_activity.super.onBackPressed();
                    back();
                }
            });

            binding.lloutLaunchDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_expiry_date_time = new Intent(Coupon_deal_activity.this, Launch_date_activity.class);
                    get_expiry_date_time.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_expiry_date_time.putExtra("navigate", "launch");

                    get_expiry_date_time.putExtra("deal", "null");
                    startActivity(get_expiry_date_time);
                }
            });


            binding.lloutExpiryDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
                    myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
                    myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
                    myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());
                    myEdit.apply();
                    Intent get_expiry_date_time = new Intent(Coupon_deal_activity.this, Launch_date_activity.class);
                    get_expiry_date_time.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_expiry_date_time.putExtra("navigate", "expiry");
                    get_expiry_date_time.putExtra("deal", "null");
                    startActivity(get_expiry_date_time);
                }
            });

            String exyeae = sh.getString("expiry_launch_year", "");
            String exmonthh = sh.getString("expiry_launch_month", "");
            String exmonthhnu = sh.getString("expiry_launch_monthnu", "");
            String exdate = sh.getString("expiry_launch_date", "");
            String extime = sh.getString("expiry_launch_time", "");
            if (preferences2.get(Coupon_deal_activity.this, preferences2.KEY_Type3).equals("5")) {

                exyeae = sh.getString("expiry_launch_year", "");
                exmonthh = sh.getString("expiry_launch_month", "");
                exmonthhnu = sh.getString("expiry_launch_monthnu", "");
                exdate = sh.getString("expiry_launch_date", "");
                extime = sh.getString("expiry_launch_time", "");

                binding.edtExpiryDateTime.setText(exdate + "/" + exmonthhnu + "/" + exyeae + " " + extime);
            }

            if (preferences2.get(Coupon_deal_activity.this, preferences2.KEY_Type3).equals("100")) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.MONTH, 1);
                    Date date = cal.getTime();
                    Log.d("devi4", "onCreate: " + date);
                    SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    String date1 = format1.format(date);
                    binding.edtExpiryDateTime.setText(date1);
                }
            }
        } else if (getIntent().getStringExtra("type").equals("2")) {

            flag = "edit";
            Log.d("devi5", "onCreate: else");

            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();

            String currency = sh.getString("currency", "");
            String deal_type = sh.getString("dealtype", "");
            String regular_price = sh.getString("regular_price", "");
            String offer_price = sh.getString("offer_price", "");
            String calculation = sh.getString("calculation", "");
            String launchdate = sh.getString("launchdate", "");
            String exprirydate = sh.getString("exprirydate", "");
            String description = sh.getString("description", "");
            String final_launch_time = sh.getString("final_launch_time", "");
            String final_expiry_time = sh.getString("final_expiry_time", "");
            String maximum_redumption = sh.getString("maximum_redumption", "");
            String can_share = sh.getString("share", "");
            String single = sh.getString("use", "");


            Log.d("viru_deal2", "onResponse: " + currency + regular_price + offer_price
                    + can_share + single + calculation + launchdate + exprirydate + maximum_redumption);

            binding.txtCurrencyType.setText(currency);
            binding.txtDealtypeDiscount.setText(deal_type);
            binding.edtRegularPriceValue.setText(regular_price);
            binding.edtOfferPriceValue.setText(offer_price);
            binding.txtCalculationPercentage.setText(calculation);
            binding.edtDateTimePicker.setText(launchdate + " " + final_launch_time);
            binding.edtExpiryDateTime.setText(exprirydate + " " + final_expiry_time);
            binding.txtDescription.setText(description);
            binding.txtMaximumAmount.setText(maximum_redumption);

            binding.txtShare.setText(can_share);
            binding.txtSingleYes.setText(single);

            binding.edtRegularPriceValue.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String edit_title = binding.edtRegularPriceValue.getText().toString();
                    myEdit.putString("regular_price", edit_title);
                    myEdit.apply();
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtOfferPriceValue.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String edtOfferPriceValue = binding.edtOfferPriceValue.getText().toString();
                    myEdit.putString("offer_price", edtOfferPriceValue);
                    myEdit.apply();
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.txtDescription.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String description = binding.txtDescription.getText().toString();
                    myEdit.putString("description", description);
                    myEdit.apply();
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.txtMaximumAmount.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String txtMaximumAmount = binding.txtMaximumAmount.getText().toString();
                    myEdit.putString("maximum_redumption", txtMaximumAmount);
                    myEdit.apply();
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });


            binding.lloutDealtype.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, dealtype_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    startActivity(get_dealtype);
                }
            });

            binding.lloutShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, share_and_use_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    get_dealtype.putExtra("navigate", "share");
                    startActivity(get_dealtype);
                }
            });
            binding.lloutUses.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, share_and_use_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    get_dealtype.putExtra("navigate", "use");
                    startActivity(get_dealtype);
                }
            });
            binding.lloutCurrency.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, Show_Currency_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    startActivity(get_dealtype);
                }
            });
            binding.txtCalculationPercentage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(Coupon_deal_activity.this, show_calculation_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    startActivity(get_dealtype);
                }
            });

            binding.imgCouponDealBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Editback();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        back();
    }

    public void back() {

        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

        if (!binding.txtDealtypeDiscount.getText().toString().isEmpty() &&
                !binding.txtCurrencyType.getText().toString().isEmpty() &&
                !binding.txtCalculationPercentage.getText().toString().isEmpty() &&
                !binding.txtShare.getText().toString().isEmpty() &&
                !binding.txtSingleYes.getText().toString().isEmpty() &&
                !binding.txtDescription.getText().toString().isEmpty() &&
                !binding.txtMaximumAmount.getText().toString().isEmpty() &&
                !binding.txtRegularPrice.getText().toString().isEmpty() &&
                !binding.txtOfferPrice.getText().toString().isEmpty()
        ) {

            //launch date and time
            String launch_deal_year = sh.getString("year_deal", "");
            String launch_deal_month = sh.getString("month_deal", "");
            String launch_deal_date = sh.getString("date_deal", "");
            String launch_deal_time = sh.getString("time_deal", "");

            //expiry date and time

            String expiry_deal_year = sh.getString("expiry_year", "");
            String expiry_deal_month = sh.getString("expiry_month", "");
            String expiry_deal_date = sh.getString("expiry_date", "");
            String expiry_deal_time = sh.getString("expiry_time", "");


            Log.d("final_launch_date", "back:  " + launch_deal_year + " " + launch_deal_month + " " + launch_deal_date + " " + launch_deal_time);
            Log.d("final_expiry_date", "back:  " + expiry_deal_year + " " + expiry_deal_month + " " + expiry_deal_date + " " + expiry_deal_time);

            String dealtype = binding.txtDealtypeDiscount.getText().toString();
            String currency = binding.txtCurrencyType.getText().toString();
            String calculation = binding.txtCalculationPercentage.getText().toString();
            String share = binding.txtShare.getText().toString();
            String use = binding.txtSingleYes.getText().toString();
            String Description = binding.txtDescription.getText().toString();
            String maximumamount = binding.txtMaximumAmount.getText().toString();
            String regular_price = binding.edtRegularPriceValue.getText().toString();
            String offer_price = binding.edtOfferPriceValue.getText().toString();
            String expriree_times = binding.edtExpiryDateTime.getText().toString();

            myEdit.putString("deal_dealtype", dealtype);
            myEdit.putString("deal_currency", currency);
            myEdit.putString("deal_calculation", calculation);
            myEdit.putString("deal_share", share);
            myEdit.putString("deal_use", use);
            myEdit.putString("deal_Description", Description);
            myEdit.putString("deal_maximumamount", maximumamount);
            myEdit.putString("deal_regular_price", regular_price);
            myEdit.putString("deal_offer_price", offer_price);
            myEdit.putString("launch_deal_year", launch_deal_year);
            myEdit.putString("launch_deal_month", launch_deal_month);
            myEdit.putString("launch_deal_date", launch_deal_date);
            myEdit.putString("launch_deal_time", launch_deal_time);
            myEdit.putString("expiry_deal_year", expiry_deal_year);
            myEdit.putString("expiry_deal_month", expiry_deal_month);
            myEdit.putString("expiry_deal_date", expiry_deal_date);
            myEdit.putString("expiry_deal_time", expiry_deal_time);
            myEdit.putString("expriree_times", expriree_times);

            myEdit.putString("Rprice", regular_price);
            myEdit.putString("offerpricce", offer_price);
            myEdit.putString("Dessss", Description);
            myEdit.putString("maxi", maximumamount);


            myEdit.putString("Rprice", binding.edtRegularPriceValue.getText().toString().trim());
            myEdit.putString("offerpricce", binding.edtOfferPriceValue.getText().toString().trim());
            myEdit.putString("Dessss", binding.txtDescription.getText().toString().trim());
            myEdit.putString("maxi", binding.txtMaximumAmount.getText().toString().trim());

            preferences.save(Coupon_deal_activity.this, preferences.KEY_Type5, String.valueOf(2));
            myEdit.apply();

            Intent get_deal_type = new Intent(Coupon_deal_activity.this, Addcoupon_activity.class);
            get_deal_type.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            get_deal_type.putExtra("type", "1");
            get_deal_type.putExtra("type2", "35");
            startActivity(get_deal_type);

        } else {
            Toast.makeText(this, "Please Fill all Fields", Toast.LENGTH_SHORT).show();

//            }
        }
    }

    public void Editback() {

        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = pref.edit();

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

        if (!binding.txtDealtypeDiscount.getText().toString().isEmpty() &&
                !binding.txtCurrencyType.getText().toString().isEmpty() &&
                !binding.txtCalculationPercentage.getText().toString().isEmpty() &&
                !binding.txtShare.getText().toString().isEmpty() &&
                !binding.txtSingleYes.getText().toString().isEmpty() &&
                !binding.txtDescription.getText().toString().isEmpty() &&
                !binding.txtMaximumAmount.getText().toString().isEmpty() &&
                !binding.txtRegularPrice.getText().toString().isEmpty() &&
                !binding.txtOfferPrice.getText().toString().isEmpty()
        ) {

            //launch date and time
            String launch_deal_year = sh.getString("year_deal", "");
            String launch_deal_month = sh.getString("month_deal", "");
            String launch_deal_date = sh.getString("date_deal", "");
            String launch_deal_time = sh.getString("time_deal", "");

            //expiry date and time

            String expiry_deal_year = sh.getString("expiry_year", "");
            String expiry_deal_month = sh.getString("expiry_month", "");
            String expiry_deal_date = sh.getString("expiry_date", "");
            String expiry_deal_time = sh.getString("expiry_time", "");


            Log.d("final_launch_date", "back:  " + launch_deal_year + " " + launch_deal_month + " " + launch_deal_date + " " + launch_deal_time);
            Log.d("final_expiry_date", "back:  " + expiry_deal_year + " " + expiry_deal_month + " " + expiry_deal_date + " " + expiry_deal_time);

            String dealtype = binding.txtDealtypeDiscount.getText().toString();
            String currency = binding.txtCurrencyType.getText().toString();
            String calculation = binding.txtCalculationPercentage.getText().toString();
            String share = binding.txtShare.getText().toString();
            String use = binding.txtSingleYes.getText().toString();
            String Description = binding.txtDescription.getText().toString();
            String maximumamount = binding.txtMaximumAmount.getText().toString();
            String regular_price = binding.edtRegularPriceValue.getText().toString();
            String offer_price = binding.edtOfferPriceValue.getText().toString();
            String expriree_times = binding.edtExpiryDateTime.getText().toString();

            Log.d("edit_dara", "Editback: " + dealtype + currency + calculation + share + use + Description + maximumamount + regular_price + offer_price + expriree_times);

            myEdit.putString("dealtype", dealtype);
            myEdit.putString("currency", currency);
            myEdit.putString("calculation", calculation);
            myEdit.putString("share", share);
            myEdit.putString("use", use);
            myEdit.putString("description", Description);
            myEdit.putString("maximum_redumption", maximumamount);
            myEdit.putString("regular_price", regular_price);
            myEdit.putString("offer_price", offer_price);
            myEdit.putString("launch_deal_year", launch_deal_year);
            myEdit.putString("launch_deal_month", launch_deal_month);
            myEdit.putString("launch_deal_date", launch_deal_date);
            myEdit.putString("final_launch_time", launch_deal_time);
            myEdit.putString("expiry_deal_year", expiry_deal_year);
            myEdit.putString("expiry_deal_month", expiry_deal_month);
            myEdit.putString("expiry_deal_date", expiry_deal_date);
            myEdit.putString("final_expiry_time", expiry_deal_time);
            myEdit.putString("exprirydate", expriree_times);
            myEdit.putString("launchdate", expriree_times);
            preferences.save(Coupon_deal_activity.this, preferences.KEY_Type5, String.valueOf(2));
            myEdit.apply();

            Intent get_deal_type = new Intent(Coupon_deal_activity.this, Addcoupon_activity.class);
            get_deal_type.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            get_deal_type.putExtra("type", "2");
            get_deal_type.putExtra("type2", "30");
            startActivity(get_deal_type);

        } else {
            Toast.makeText(this, "Please Fill all Fields", Toast.LENGTH_SHORT).show();

        }
//        }
    }
}

