
package com.example.local_coupan.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.local_coupan.databinding.ActivityShareBinding;

public class Share_activity extends AppCompatActivity {
    ActivityShareBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShareBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.imgShareBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gt_main = new Intent(Share_activity.this, MainActivity.class);
                gt_main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(gt_main);
                finish();
            }
        });

        binding.lloutDirectShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_direct_share = new Intent(Share_activity.this, Direct_share_Activity.class);
                get_direct_share.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(get_direct_share);
            }
        });

        binding.lloutMessageGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent get_market = new Intent(Share_activity.this, select_market_group_activity.class);
                get_market.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                get_market.putExtra("navigate", "share_message");
                startActivity(get_market);
            }
        });
    }
}