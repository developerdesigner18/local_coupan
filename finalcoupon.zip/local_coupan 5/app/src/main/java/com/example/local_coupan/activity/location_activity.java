package com.example.local_coupan.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.local_coupan.databinding.ActivityLocationBinding;
import com.example.local_coupan.preferences2;
import com.google.firebase.firestore.GeoPoint;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import kotlin.jvm.internal.Intrinsics;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class location_activity extends AppCompatActivity {

    ActivityLocationBinding binding;
    public int GALLERY_REQ_CODE;
    JSONArray jsonArray2 = new JSONArray();
    preferences2 preferences;
    String arraytext;

    private Bitmap bitmap;
    MultipartBody.Part part;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLocationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Log.d("devi5", "onCreate: " + getIntent().getStringExtra("type"));
        if (getIntent().getStringExtra("type").equals("1")) {

            Bundle b = getIntent().getExtras();
            arraytext = b.getString("Array");
            String bitmap6 = preferences.get(location_activity.this, preferences.KEY_lbitmap);
            Bitmap btt = StringToBitMap(bitmap6);
            binding.imgFromUserLocation.setImageBitmap(btt);
            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
            Log.d("llimages", "onCreate: " + btt);

            String latitude = sh.getString("latitude", "");
            String longitude = sh.getString("longitude", "");
            String country = sh.getString("country", "");
            String address1 = sh.getString("address1", "");
            String address2 = sh.getString("address2", "");
            String town_city = sh.getString("town_city", "");
            String postcode = sh.getString("postcode", "");
            String opening_times = sh.getString("opening_times", "");

            if (!latitude.isEmpty() && !longitude.isEmpty()) {

                String final_latitude = latitude.substring(0, 6);
                String final_longitude = longitude.substring(0, 6);

                binding.txtLatitude.setText(final_latitude);
                binding.txtLongitude.setText(final_longitude);
            }

            binding.dash.setVisibility(View.VISIBLE);
            binding.txtCountryName.setText(country);
            binding.edtAddress1.setText(address1);
            binding.edtAddress2.setText(address2);
            binding.edtTownCity.setText(town_city);
            binding.edtPostcode.setText(postcode);
            binding.edtOpningtimes.setText(opening_times);

            binding.cardAddCoupon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_add = new Intent(location_activity.this, Addcoupon_activity.class);
                    preferences.save(location_activity.this, preferences.KEY_Type4, String.valueOf(6));
                    get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();
                    String jsonArray2 = sh.getString("location_datas", "");
                    String latitude = binding.txtLatitude.getText().toString();
                    String longitude = binding.txtLongitude.getText().toString();
                    String country = binding.txtCountryName.getText().toString();
                    myEdit.putString("Array_location", jsonArray2);
                    myEdit.putString("address1", String.valueOf(binding.edtAddress1.getText().toString()));
                    myEdit.putString("address2", String.valueOf(binding.edtAddress2.getText().toString()));
                    myEdit.putString("town_city", String.valueOf(binding.edtTownCity.getText().toString()));
                    myEdit.putString("postcode", String.valueOf(binding.edtPostcode.getText().toString()));
                    myEdit.putString("opening_times", String.valueOf(binding.edtOpningtimes.getText().toString()));
                    myEdit.putString("latitude", String.valueOf(binding.txtLatitude.getText().toString()));
                    myEdit.putString("longitude", String.valueOf(binding.txtLongitude.getText().toString()));
                    myEdit.putString("country", String.valueOf(binding.txtCountryName.getText().toString()));

                    myEdit.apply();
                    Log.d("devi6 l ", "onClick: " + binding.edtAddress1.getText().toString());
                    get_add.putExtra("Array_location", String.valueOf(jsonArray2));
                    get_add.putExtra("type", "1");
                    get_add.putExtra("type2", "10");
                    startActivity(get_add);
                    Log.d("deviaddd 1", "onClick: 2 " + jsonArray2);

                }
            });

            binding.lloutLocationOnMap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String opening_times = Objects.requireNonNull(binding.edtOpningtimes.getText()).toString();
                    String address1 = Objects.requireNonNull(binding.edtAddress1.getText()).toString();
                    String address2 = Objects.requireNonNull(binding.edtAddress2.getText()).toString();
                    String town_city = Objects.requireNonNull(binding.edtTownCity.getText()).toString();
                    String postcode = Objects.requireNonNull(binding.edtPostcode.getText()).toString();
                    String country = binding.txtCountryName.getText().toString();

                    String full_address = address1 + address2 + town_city + postcode;

                    if (address1.isEmpty() && address2.isEmpty() && town_city.isEmpty() && postcode.isEmpty() && country.isEmpty()) {

                        Intent get_map = new Intent(location_activity.this, select_maps_Activity.class);
                        get_map.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                        SharedPreferences.Editor myEdit = pref.edit();

                        myEdit.putString("address1", address1);
                        myEdit.putString("address2", address2);
                        myEdit.putString("town_city", town_city);
                        myEdit.putString("postcode", postcode);
                        myEdit.putString("opening_times", opening_times);

                        myEdit.putString("new_location", "first");
                        myEdit.apply();
                        get_map.putExtra("map_pin", "current");
                        startActivity(get_map);

                    } else if (!address1.isEmpty() && !address2.isEmpty() && !town_city.isEmpty() && !postcode.isEmpty()) {

                        getLocationFromAddress(full_address);

                    } else {

                        Toast.makeText(location_activity.this, "An Error Occurred", Toast.LENGTH_SHORT).show();

                    }
                }
            });
            binding.lloutImgUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (Build.VERSION.SDK_INT >= 23) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            selectImage();
                        } else {
                            ActivityCompat.requestPermissions(location_activity.this, new String[]{
                                            Manifest.permission.CAMERA},
                                    1);
                        }
                    }
                }
            });
            binding.imgLocationBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_add = new Intent(location_activity.this, Addcoupon_activity.class);
                    preferences.save(location_activity.this, preferences.KEY_Type4, String.valueOf(6));
                    get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();
                    String jsonArray2 = sh.getString("location_datas", "");
                    String latitude = binding.txtLatitude.getText().toString();
                    String longitude = binding.txtLongitude.getText().toString();
                    String country = binding.txtCountryName.getText().toString();
                    myEdit.putString("Array_location", jsonArray2);
                    myEdit.putString("address1", String.valueOf(binding.edtAddress1.getText().toString()));
                    myEdit.putString("address2", String.valueOf(binding.edtAddress2.getText().toString()));
                    myEdit.putString("town_city", String.valueOf(binding.edtTownCity.getText().toString()));
                    myEdit.putString("postcode", String.valueOf(binding.edtPostcode.getText().toString()));
                    myEdit.putString("opening_times", String.valueOf(binding.edtOpningtimes.getText().toString()));
                    myEdit.putString("latitude", String.valueOf(binding.txtLatitude.getText().toString()));
                    myEdit.putString("longitude", String.valueOf(binding.txtLongitude.getText().toString()));
                    myEdit.putString("country", String.valueOf(binding.txtCountryName.getText().toString()));

                    myEdit.apply();
                    Log.d("devi6 l ", "onClick: " + binding.edtAddress1.getText().toString());
                    get_add.putExtra("Array_location", String.valueOf(jsonArray2));
                    get_add.putExtra("type", "1");
                    get_add.putExtra("type2", "10");
                    startActivity(get_add);
                    Log.d("deviaddd 1", "onClick: 2 " + jsonArray2);

                }
            });
            binding.lloutcountry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_country = new Intent(location_activity.this, select_country_activity.class);
                    get_country.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    String address1 = Objects.requireNonNull(binding.edtAddress1.getText()).toString();
                    String address2 = Objects.requireNonNull(binding.edtAddress2.getText()).toString();
                    String town_city = Objects.requireNonNull(binding.edtTownCity.getText()).toString();
                    String postcode = Objects.requireNonNull(binding.edtPostcode.getText()).toString();
                    String opening_times = Objects.requireNonNull(binding.edtOpningtimes.getText()).toString();

                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();

                    myEdit.putString("address1", address1);
                    myEdit.putString("address2", address2);
                    myEdit.putString("town_city", town_city);
                    myEdit.putString("postcode", postcode);
                    myEdit.putString("opening_times", opening_times);
                    myEdit.apply();
//                    myEdit.putString("Array", String.valueOf(jsonArray2));

                    get_country.putExtra("type", "1");
                    startActivity(get_country);
                }
            });
        } else if (getIntent().getStringExtra("type").equals("2")) {

            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();
            SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

            String adress1 = sh.getString("address1", "");
            String adress2 = sh.getString("address2", "");
            String town_city = sh.getString("town_city", "");
            String country = sh.getString("country", "");
            String location = sh.getString("location", "");
            String opening_time = sh.getString("opening_time", "");
            String location_image = sh.getString("location_image", "");
            String postcode = sh.getString("postcode", "");
            String latitude = sh.getString("latitude", "");
            String longitude = sh.getString("longitude", "");

            Log.d("viru_location", "onCreate: " + adress2 + adress1 + town_city + country + location + opening_time + location_image);

            binding.edtAddress1.setText(adress1);
            binding.edtAddress2.setText(adress2);
            binding.edtTownCity.setText(town_city);
            binding.txtCountryName.setText(country);
            binding.edtOpningtimes.setText(opening_time);
            binding.edtPostcode.setText(postcode);
            binding.txtLatitude.setText(latitude);
            binding.txtLongitude.setText(longitude);


            binding.edtAddress1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String address1 = binding.edtAddress1.getText().toString();
                    myEdit.putString("address1", address1);
                    myEdit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtAddress2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String address1 = binding.edtAddress2.getText().toString();
                    myEdit.putString("address2", address1);
                    myEdit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtTownCity.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String address1 = binding.edtTownCity.getText().toString();
                    myEdit.putString("town_city", address1);
                    myEdit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtPostcode.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String address1 = binding.edtPostcode.getText().toString();
                    myEdit.putString("postcode", address1);
                    myEdit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            binding.edtOpningtimes.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String address1 = binding.edtOpningtimes.getText().toString();
                    myEdit.putString("opening_time", address1);
                    myEdit.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });


            String image = location_image;

            URL url = null;
            try {
                url = new URL(image);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            Picasso.get().load(String.valueOf(url)).into(binding.imgFromUserLocation);


            binding.lloutcountry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_dealtype = new Intent(location_activity.this, select_country_activity.class);
                    get_dealtype.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_dealtype.putExtra("type", "2");
                    startActivity(get_dealtype);
                }
            });

            binding.imgLocationBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_add = new Intent(location_activity.this, Addcoupon_activity.class);
                    preferences.save(location_activity.this, preferences.KEY_Type4, String.valueOf(6));
                    get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = pref.edit();
//                    String jsonArray2 = sh.getString("location_datas", "");
                    String latitude = binding.txtLatitude.getText().toString();
                    String longitude = binding.txtLongitude.getText().toString();
                    String country = binding.txtCountryName.getText().toString();
//                    myEdit.putString("Array_location", jsonArray2);
                    myEdit.putString("address1", String.valueOf(binding.edtAddress1.getText().toString()));
                    myEdit.putString("address2", String.valueOf(binding.edtAddress2.getText().toString()));
                    myEdit.putString("town_city", String.valueOf(binding.edtTownCity.getText().toString()));
                    myEdit.putString("postcode", String.valueOf(binding.edtPostcode.getText().toString()));
                    myEdit.putString("opening_times", String.valueOf(binding.edtOpningtimes.getText().toString()));
                    myEdit.putString("latitude", String.valueOf(binding.txtLatitude.getText().toString()));
                    myEdit.putString("longitude", String.valueOf(binding.txtLongitude.getText().toString()));
                    myEdit.putString("country", String.valueOf(binding.txtCountryName.getText().toString()));

                    myEdit.apply();
                    Log.d("devi6 l ", "onClick: " + binding.edtAddress1.getText().toString());
                    get_add.putExtra("Array_location", String.valueOf(jsonArray2));
                    get_add.putExtra("type", "2");
                    get_add.putExtra("type2", "30");
                    startActivity(get_add);
                    Log.d("deviaddd 1", "onClick: 2 " + jsonArray2);

                }
            });


            binding.lloutLocationOnMap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent get_map = new Intent(location_activity.this, select_maps_Activity.class);
                    get_map.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_map.putExtra("type", "2");
                    startActivity(get_map);

                }
            });

            binding.cardAddCoupon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent get_add = new Intent(location_activity.this, Addcoupon_activity.class);
                    preferences.save(location_activity.this, preferences.KEY_Type4, String.valueOf(6));
                    get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    get_add.putExtra("type", "2");
                    get_add.putExtra("type2", "30");
                    startActivity(get_add);
                }
            });
            binding.lloutImgUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

//                    checkPermission();

                    if (Build.VERSION.SDK_INT >= 23) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            selectImage();

                        } else {
                            ActivityCompat.requestPermissions(location_activity.this, new String[]{
                                            Manifest.permission.CAMERA},
                                    1);
                        }
                    }
                }
            });
        }
    }

    private void selectImage() {
        Intent i_gallary = new Intent();
        i_gallary.setType("image/*");
        i_gallary.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(i_gallary, "Select Picture"), GALLERY_REQ_CODE);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQ_CODE) {
            Uri selectedImageUri = data.getData();

            if (null != selectedImageUri) {
                bitmap = BitmapFactory.decodeFile(String.valueOf(selectedImageUri));
                try {
                    InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                    bitmap = BitmapFactory.decodeStream(inputStream);
                    binding.imgFromUserLocation.setImageBitmap(bitmap);
                    String btos = BitMapToString(bitmap);
                    preferences.save(location_activity.this, preferences.KEY_lbitmap, String.valueOf(btos));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                File file = new File(getRealPathFromURI(selectedImageUri, getApplicationContext()));

                SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = pref.edit();
                myEdit.putString("lastimageloaction", String.valueOf(file));
                myEdit.apply();
                RequestBody requestBody = RequestBody.create(MediaType.parse("image/"), file);
                part = MultipartBody.Part.createFormData("addressImage", file.getName(), requestBody);
                Log.d("filepath", "onActivityResult: " + file);

//                SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
//                SharedPreferences.Editor myEdit = pref.edit();
            }
        }
    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {

            } else {
                ActivityCompat.requestPermissions(this, new String[]{
                                Manifest.permission.CAMERA},
                        1);
            }
        }
    }

//    public void Add() {
//
//        SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
//        SharedPreferences.Editor myEdit = pref.edit();
//        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
//
//        myEdit.putString("new_location", "first");
//        if (!binding.edtAddress1.getText().toString().isEmpty() &&
//                !binding.edtAddress2.getText().toString().isEmpty()
////                &&
////                !binding.edtTownCity.getText().toString().isEmpty() &&
////                !binding.edtPostcode.getText().toString().isEmpty() &&
////                !binding.txtLatitude.getText().toString().isEmpty() &&
////                !binding.txtLongitude.getText().toString().isEmpty() &&
////                !binding.txtCountryName.getText().toString().isEmpty() &&
////                !binding.edtOpningtimes.getText().toString().isEmpty()
//        ) {
//
//            Intent get_deal_type = new Intent(location_activity.this, Addcoupon_activity.class);
//            get_deal_type.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//            preferences.save(location_activity.this, preferences.KEY_Type4, String.valueOf(6));
//            get_deal_type.putExtra("type", "1");
//            get_deal_type.putExtra("type2", "35");
//            String Address1 = binding.edtAddress1.getText().toString();
//            String Address2 = binding.edtAddress2.getText().toString();
//            String Postcode = binding.edtPostcode.getText().toString();
//            String towncity = binding.edtTownCity.getText().toString();
//            String openingTimes = binding.edtOpningtimes.getText().toString();
//            String latitude = binding.txtLatitude.getText().toString();
//            String longitude = binding.txtLongitude.getText().toString();
//            String country = binding.txtCountryName.getText().toString();
//            String final_image_uri = sh.getString("image_uri", "");
//
//            Object image_object = final_image_uri;
//
//            Log.d("final_image_uri", "Add: " + image_object);
//            Log.d("location_data", "back: " + Address1 + Address2 + Postcode + towncity + openingTimes + latitude + longitude + country + image_object);
//
//            try {
//
//                // ADD
//
//                JSONObject object = new JSONObject();
//
//                JSONArray jsonArray = new JSONArray(arraytext);
//                object.put("address1", Address1);
//                object.put("address2", Address2);
//                object.put("postcode", Postcode);
//                object.put("city", towncity);
//                object.put("openingTimes", openingTimes);
//                object.put("latitude", latitude);
//                object.put("longitude", longitude);
//                object.put("country", country);
//                object.put("addressImage", part);
//
//                jsonArray.put(object);
//
//                Log.d("devi1 location", "onCreate: 2 " + jsonArray);
//
//                jsonArray2 = jsonArray;
//                myEdit.putString("location_datas", String.valueOf(jsonArray2));
//                binding.imgLocationBack.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Intent get_add = new Intent(location_activity.this, Addcoupon_activity.class);
//                        get_add.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        myEdit.putString("Array_location", String.valueOf(jsonArray2));
//                        myEdit.apply();
//                        get_add.putExtra("Array_location", String.valueOf(jsonArray2));
//                        get_add.putExtra("type", "1");
//                        get_add.putExtra("type2", "10");
//                        startActivity(get_add);
//                        Log.d("deviaddd 1", "onClick: 3 " + String.valueOf(jsonArray2));
//
//                    }
//                });
//            } catch (JSONException e) {
//                Log.d("location_data", "Add: " + e);
//                e.printStackTrace();
//            }
//
//            Handler handler = new Handler();
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//
//                    binding.edtAddress1.setText("");
//                    binding.edtAddress2.setText("");
//                    binding.edtPostcode.setText("");
//                    binding.edtTownCity.setText("");
//                    binding.txtCountryName.setText("");
//                    binding.txtLatitude.setText("");
//                    binding.txtLongitude.setText("");
//                    binding.edtOpningtimes.setText("");
//                    binding.dash.setVisibility(View.GONE);
////                    binding.imgFromUserLocation.setImageResource(R.drawable.ic_launcher_foreground);
//
//                    myEdit.putString("latitude", "");
//                    myEdit.putString("longitude", "");
//                    myEdit.putString("country", "");
//                    myEdit.apply();
//                }
//            }, 1000);
//        } else {
//            Toast.makeText(this, "Please Fill all Fields", Toast.LENGTH_SHORT).show();
//        }
//    }

    public GeoPoint getLocationFromAddress(String strAddress) {

        Geocoder coder = new Geocoder(this);
        List<Address> address;
        GeoPoint p1 = null;

        try {

            address = coder.getFromLocationName(strAddress, 2);
            if (address == null) {
                return null;
            }


            Log.d("location123", "getLocationFromAddress: " + "location");
            Address location = address.get(0);
            Log.d("location123", "getLocationFromAddress: " + location);
            location.getLatitude();
            location.getLongitude();
            double l1 = location.getLatitude();
            double l2 = location.getLongitude();
            Log.d("devi22", "getLocationFromAddress: " + l1 + " " + l2);
//            Toast.makeText(this, "" + l1 + " " + l2, Toast.LENGTH_SHORT).show();
            SharedPreferences pref = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = pref.edit();

            String latitude = String.valueOf(l1);
            String longitude = String.valueOf(l2);

            binding.txtLatitude.setText(latitude);
            binding.txtLongitude.setText(longitude);

            myEdit.putString("latitude123", latitude);
            myEdit.putString("longitude123", longitude);
            myEdit.apply();

            Geocoder geoCoder = new Geocoder(getBaseContext(), Locale.getDefault());
            try {
                List<Address> addresses = geoCoder.getFromLocation(l1, l2, 1);

                String add = "";
                if (addresses.size() > 0) {
                    for (int i = 0; i < addresses.get(0).getMaxAddressLineIndex(); i++)
                        add += addresses.get(0).getAddressLine(i) + "\n";

                }

                Intent get_map = new Intent(location_activity.this, select_maps_Activity.class);
                get_map.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                String address1 = Objects.requireNonNull(binding.edtAddress1.getText()).toString();
                String address2 = Objects.requireNonNull(binding.edtAddress2.getText()).toString();
                String town_city = Objects.requireNonNull(binding.edtTownCity.getText()).toString();
                String postcode = Objects.requireNonNull(binding.edtPostcode.getText()).toString();
                String opening_times = Objects.requireNonNull(binding.edtOpningtimes.getText()).toString();


                get_map.putExtra("address1", address1);
                get_map.putExtra("address2", address2);
                get_map.putExtra("town_city", town_city);
                get_map.putExtra("postcode", postcode);
                get_map.putExtra("opening_times", opening_times);
                myEdit.putString("new_location", "first");
                myEdit.apply();
                get_map.putExtra("type", "1");
//                startActivity(get_map);

                Log.d("viru_location222", "getLocationFromAddress: " + address.get(0).getCountryName());

                String select_country = binding.txtCountryName.getText().toString();


                if (address.get(0).getCountryName().equals(select_country)) {

                    Log.d("location_address", "getLocationFromAddress: " + "address");
                    get_map.putExtra("map_pin", "address");
                    startActivity(get_map);

                } else {
                    Log.d("location_address", "getLocationFromAddress: " + "current");
                    get_map.putExtra("map_pin", "current");
                    startActivity(get_map);

                }

//                Toast.makeText(this, "" + address.get(0).getCountryName(), Toast.LENGTH_SHORT).show();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            return p1;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Nullable
    public final String getRealPathFromURI(@NotNull Uri uri, @NotNull Context context) {
        Intrinsics.checkNotNullParameter(uri, "uri");
        Intrinsics.checkNotNullParameter(context, "context");
        Cursor returnCursor = context.getContentResolver().query(uri, (String[]) null, (String) null, (String[]) null, (String) null);
        Intrinsics.checkNotNull(returnCursor);
        int nameIndex = returnCursor.getColumnIndex("_display_name");
        int sizeIndex = returnCursor.getColumnIndex("_size");
        returnCursor.moveToFirst();
        String name = returnCursor.getString(nameIndex);
        String size = String.valueOf(returnCursor.getLong(sizeIndex));
        File file = new File(context.getFilesDir(), name);

        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1048576;
            int bytesAvailable = inputStream != null ? inputStream.available() : 0;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
            byte[] buffers = new byte[bufferSize];

            while (true) {
                Integer var16 = inputStream != null ? inputStream.read(buffers) : null;
                boolean var18 = false;
                if (var16 != null) {
                    read = var16;
                }

                if (var16 != null) {
                    if (var16 == -1) {
                        Log.e("File Size", "Size " + file.length());
                        if (inputStream != null) {
                            inputStream.close();
                        }

                        outputStream.close();
                        Log.e("File Path", "Path " + file.getPath());
                        break;
                    }
                }

                outputStream.write(buffers, 0, read);
            }
        } catch (Exception var19) {
            String var10001 = var19.getMessage();
            Intrinsics.checkNotNull(var10001);
            Log.e("Exception", var10001);
        }

        return file.getPath();
    }

    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    public Bitmap StringToBitMap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0,
                    encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }
}